# Alex Friend (Forge 1.12.2)

Alex is a friendly NPC you can spawn from the creative inventory.

## Getting her in game
- Creative inventory -> **Miscellaneous** tab (or search "Alex") -> **Spawn Alex** egg.
- Right click her once to become friends, then right click again to open her menu.

## Menu actions
Chat, Hug, Pat her head, Give gift (item in your main hand), Dance together, Wave,
Compliment her, Tell a joke, Ask for a snack (needs friendship 10+), Ask for a flower,
Follow me, Wait here, Sit / Stand, Come here.

After every action she answers automatically in chat as `<Alex> ...` and her face reacts.
Friendship grows with actions and gifts (New friend -> Friend at 20 -> Best friend at 60), and her
lines change with it. She also talks on her own every few minutes and worries when you are hurt or hungry.

## Skin / face
`assets/alexfriend/textures/entity/alex.png` is the faceless skin (hair, bangs, body).
The animated face is drawn in game by `LayerAlexFace` from the 8x8 images in
`textures/entity/face/` (`face_<eyes>_<mouth>[_b].png`). Edit those PNGs to restyle her face.

## Building
GitHub Actions: put `AlexFriendMod.zip` in the repository root and `build.yml` in `.github/workflows/`.
The workflow extracts the zip and builds the jar (Java 8 + 21, Gradle 8.12, RetroFuturaGradle (Forge 1.12.2 14.23.5.2847)).
The jar is uploaded as an artifact named `AlexFriend-jar`.
