package com.alexfriend;

import com.alexfriend.entity.EntityAlex;
import com.alexfriend.network.PacketAction;
import com.alexfriend.network.PacketOpenMenu;
import com.alexfriend.proxy.CommonProxy;

import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.common.registry.EntityRegistry;
import net.minecraftforge.fml.relauncher.Side;

@Mod(modid = AlexMod.MODID, name = "Alex Friend", version = "1.0.0", acceptedMinecraftVersions = "[1.12.2]")
public class AlexMod {
    public static final String MODID = "alexfriend";

    @Mod.Instance(MODID)
    public static AlexMod instance;

    @SidedProxy(clientSide = "com.alexfriend.proxy.ClientProxy", serverSide = "com.alexfriend.proxy.CommonProxy")
    public static CommonProxy proxy;

    public static SimpleNetworkWrapper network;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        network = NetworkRegistry.INSTANCE.newSimpleChannel(MODID);
        network.registerMessage(PacketOpenMenu.Handler.class, PacketOpenMenu.class, 0, Side.CLIENT);
        network.registerMessage(PacketAction.Handler.class, PacketAction.class, 1, Side.SERVER);

        // Registering with egg colours (orange hair / green eyes) creates the creative spawn egg.
        EntityRegistry.registerModEntity(new ResourceLocation(MODID, "alex"), EntityAlex.class, "alex", 0,
                this, 64, 1, true, 0xE59947, 0x236224);

        proxy.preInit();
    }
}
