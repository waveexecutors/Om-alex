package com.alexfriend.client;

import java.io.IOException;

import com.alexfriend.AlexMod;
import com.alexfriend.entity.AlexActions;
import com.alexfriend.entity.EntityAlex;
import com.alexfriend.network.PacketAction;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

/** The menu that opens when you right click Alex. */
public class GuiAlexMenu extends GuiScreen {
    private static final int ROWS = 7;
    private static final int ROW_H = 22;

    private final EntityAlex alex;

    public GuiAlexMenu(EntityAlex alex) {
        this.alex = alex;
    }

    @Override
    public void initGui() {
        this.buttonList.clear();
        int cx = this.width / 2;
        int top = this.height / 2 - (ROWS * ROW_H) / 2 + 14;
        for (int i = 0; i < AlexActions.LABELS.length; i++) {
            int col = i / ROWS;
            int row = i % ROWS;
            int x = col == 0 ? cx - 105 : cx + 5;
            String label = AlexActions.LABELS[i];
            if (i == AlexActions.SIT) {
                label = alex.isSitting() ? "Stand up" : "Sit down";
            }
            this.buttonList.add(new GuiButton(i, x, top + row * ROW_H, 100, 20, label));
        }
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        AlexMod.network.sendToServer(new PacketAction(alex.getEntityId(), button.id));
        this.mc.displayGuiScreen(null);
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.drawDefaultBackground();
        int cx = this.width / 2;
        int top = this.height / 2 - (ROWS * ROW_H) / 2 + 14;

        this.drawCenteredString(this.fontRenderer, "Alex", cx, top - 34, 0xFFFFFF);

        int aff = alex.getAffection();
        int barW = 200;
        int x0 = cx - barW / 2;
        int y0 = top - 20;
        drawRect(x0 - 1, y0 - 1, x0 + barW + 1, y0 + 7, 0xFF000000);
        drawRect(x0, y0, x0 + barW, y0 + 6, 0xFF3A3A3A);
        drawRect(x0, y0, x0 + (barW * aff) / 100, y0 + 6, 0xFFFF6FA5);
        String tier = aff >= 60 ? "Best friend" : (aff >= 20 ? "Friend" : "New friend");
        this.drawCenteredString(this.fontRenderer, tier + "  " + aff + "/100", cx, y0 + 9, 0xFFB6D2);

        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}
