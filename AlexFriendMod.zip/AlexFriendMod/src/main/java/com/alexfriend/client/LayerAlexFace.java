package com.alexfriend.client;

import java.util.HashMap;
import java.util.Map;

import com.alexfriend.AlexMod;
import com.alexfriend.entity.EntityAlex;

import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ResourceLocation;

/**
 * Draws Alex's animated face (8x8 textures) on the front of her head.
 * Eyes blink, the mouth moves while she talks, and the expression follows her emotion.
 */
public class LayerAlexFace implements LayerRenderer<EntityAlex> {
    private static final Map<String, ResourceLocation> CACHE = new HashMap<String, ResourceLocation>();

    private final RenderAlex renderer;

    public LayerAlexFace(RenderAlex renderer) {
        this.renderer = renderer;
    }

    private static ResourceLocation tex(String eyes, String mouth, boolean blush) {
        String name = "face_" + eyes + "_" + mouth + (blush ? "_b" : "");
        ResourceLocation rl = CACHE.get(name);
        if (rl == null) {
            rl = new ResourceLocation(AlexMod.MODID, "textures/entity/face/" + name + ".png");
            CACHE.put(name, rl);
        }
        return rl;
    }

    private ResourceLocation pickTexture(EntityAlex e) {
        String eyes;
        String mouth;
        boolean blush = false;

        switch (e.getEmotion()) {
            case EntityAlex.EMO_HAPPY:
                eyes = "happy";
                mouth = "grin";
                blush = true;
                break;
            case EntityAlex.EMO_SHY:
                eyes = "shy";
                mouth = "smile";
                blush = true;
                break;
            case EntityAlex.EMO_SAD:
                eyes = "sad";
                mouth = "frown";
                break;
            case EntityAlex.EMO_SURPRISED:
                eyes = "surprised";
                mouth = "o";
                break;
            default:
                eyes = "open";
                mouth = e.getAffection() >= 20 ? "smile" : "neutral";
                break;
        }

        // asleep when sitting at night
        if (e.getEmotion() == EntityAlex.EMO_NORMAL && e.isSitting() && (e.world.getWorldTime() % 24000L) > 13000L) {
            eyes = "blink";
        }

        // blink every ~4 seconds
        if (eyes.equals("open") && ((e.ticksExisted + e.getEntityId() * 13) % 80) < 4) {
            eyes = "blink";
        }

        // mouth moves while she is talking
        if (e.isTalking() && !mouth.equals("o") && (e.ticksExisted / 3) % 2 == 0) {
            mouth = "talk";
        }
        return tex(eyes, mouth, blush);
    }

    @Override
    public void doRenderLayer(EntityAlex entity, float limbSwing, float limbSwingAmount, float partialTicks,
            float ageInTicks, float netHeadYaw, float headPitch, float scale) {
        if (entity.isInvisible()) return;

        this.renderer.bindTexture(pickTexture(entity));
        ModelAlex model = (ModelAlex) this.renderer.getMainModel();

        GlStateManager.pushMatrix();
        model.bipedHead.postRender(scale);
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.disableCull();

        // head box spans x -4..4, y -8..0, z -4..4 (model pixels); front face is z = -4
        float z = -4.03F;
        float x0 = -4.0F * scale, x1 = 4.0F * scale;
        float y0 = -8.0F * scale, y1 = 0.0F;
        float zz = z * scale;

        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = tess.getBuffer();
        buf.begin(7, DefaultVertexFormats.OLDMODEL_POSITION_TEX_NORMAL);
        buf.pos(x0, y0, zz).tex(1.0D, 0.0D).normal(0.0F, 0.0F, -1.0F).endVertex();
        buf.pos(x1, y0, zz).tex(0.0D, 0.0D).normal(0.0F, 0.0F, -1.0F).endVertex();
        buf.pos(x1, y1, zz).tex(0.0D, 1.0D).normal(0.0F, 0.0F, -1.0F).endVertex();
        buf.pos(x0, y1, zz).tex(1.0D, 1.0D).normal(0.0F, 0.0F, -1.0F).endVertex();
        tess.draw();

        GlStateManager.enableCull();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }

    @Override
    public boolean shouldCombineTextures() {
        return false;
    }
}
