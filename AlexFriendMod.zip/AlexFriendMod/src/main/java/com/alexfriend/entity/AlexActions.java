package com.alexfriend.entity;

/** Action ids used by the menu (button id == action id). */
public class AlexActions {
    public static final int CHAT = 0;
    public static final int HUG = 1;
    public static final int HEADPAT = 2;
    public static final int GIFT = 3;
    public static final int DANCE = 4;
    public static final int WAVE = 5;
    public static final int COMPLIMENT = 6;
    public static final int JOKE = 7;
    public static final int SNACK = 8;
    public static final int FLOWER = 9;
    public static final int FOLLOW = 10;
    public static final int STAY = 11;
    public static final int SIT = 12;
    public static final int COME = 13;

    public static final String[] LABELS = {
            "Chat", "Hug", "Pat her head", "Give gift (held item)", "Dance together", "Wave",
            "Compliment her", "Tell a joke", "Ask for a snack", "Ask for a flower", "Follow me",
            "Wait here", "Sit / Stand", "Come here"
    };
}
