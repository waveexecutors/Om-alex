package com.alexfriend.network;

import com.alexfriend.entity.EntityAlex;

import io.netty.buffer.ByteBuf;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

/** Client -> server: the player picked an action in Alex's menu. */
public class PacketAction implements IMessage {
    public int entityId;
    public int action;

    public PacketAction() {
    }

    public PacketAction(int entityId, int action) {
        this.entityId = entityId;
        this.action = action;
    }

    @Override
    public void fromBytes(ByteBuf buf) {
        entityId = buf.readInt();
        action = buf.readInt();
    }

    @Override
    public void toBytes(ByteBuf buf) {
        buf.writeInt(entityId);
        buf.writeInt(action);
    }

    public static class Handler implements IMessageHandler<PacketAction, IMessage> {
        @Override
        public IMessage onMessage(final PacketAction message, MessageContext ctx) {
            final EntityPlayerMP player = ctx.getServerHandler().player;
            player.getServerWorld().addScheduledTask(new Runnable() {
                @Override
                public void run() {
                    Entity e = player.world.getEntityByID(message.entityId);
                    if (e instanceof EntityAlex && player.getDistanceSq(e) < 100.0D) {
                        ((EntityAlex) e).performAction(player, message.action);
                    }
                }
            });
            return null;
        }
    }
}
