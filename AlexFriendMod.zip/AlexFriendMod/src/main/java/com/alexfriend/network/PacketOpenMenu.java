package com.alexfriend.network;

import com.alexfriend.AlexMod;

import io.netty.buffer.ByteBuf;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

/** Server -> client: open Alex's interaction menu. */
public class PacketOpenMenu implements IMessage {
    public int entityId;

    public PacketOpenMenu() {
    }

    public PacketOpenMenu(int entityId) {
        this.entityId = entityId;
    }

    @Override
    public void fromBytes(ByteBuf buf) {
        entityId = buf.readInt();
    }

    @Override
    public void toBytes(ByteBuf buf) {
        buf.writeInt(entityId);
    }

    public static class Handler implements IMessageHandler<PacketOpenMenu, IMessage> {
        @Override
        public IMessage onMessage(PacketOpenMenu message, MessageContext ctx) {
            AlexMod.proxy.openMenu(message.entityId);
            return null;
        }
    }
}
