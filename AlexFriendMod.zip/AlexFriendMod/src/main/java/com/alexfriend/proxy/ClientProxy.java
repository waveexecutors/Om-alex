package com.alexfriend.proxy;

import com.alexfriend.client.GuiAlexMenu;
import com.alexfriend.client.RenderAlex;
import com.alexfriend.entity.EntityAlex;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraftforge.fml.client.registry.RenderingRegistry;

public class ClientProxy extends CommonProxy {
    @Override
    public void preInit() {
        RenderingRegistry.registerEntityRenderingHandler(EntityAlex.class, RenderAlex::new);
    }

    @Override
    public void openMenu(final int entityId) {
        final Minecraft mc = Minecraft.getMinecraft();
        mc.addScheduledTask(new Runnable() {
            @Override
            public void run() {
                if (mc.world == null) return;
                Entity e = mc.world.getEntityByID(entityId);
                if (e instanceof EntityAlex) {
                    mc.displayGuiScreen(new GuiAlexMenu((EntityAlex) e));
                }
            }
        });
    }
}
