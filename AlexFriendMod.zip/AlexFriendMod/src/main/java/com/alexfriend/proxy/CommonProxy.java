package com.alexfriend.proxy;

public class CommonProxy {
    public void preInit() {
    }

    public void openMenu(int entityId) {
    }
}
