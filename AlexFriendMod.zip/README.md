# Alex Friend (Forge 1.12.2)

Alex is a friendly NPC you can spawn from the creative inventory.

## Getting her in game
- Creative inventory -> **Miscellaneous** tab (or search "Alex") -> **Spawn Alex** egg.
- Right click her once to become friends, then right click again to open her menu.

## Menu actions
Chat, Hug, Pat her head, Give gift (item in your main hand), Dance together, Wave,
Compliment her, Tell a joke, Ask for a snack (needs friendship 10+), Ask for a flower,
Follow me, Wait here, Sit / Stand, Come here, **Kiss her**.

After every action she answers automatically in chat as `<Alex> ...` and her face reacts.
Friendship grows with actions and gifts (New friend -> Friend at 20 -> Best friend at 60), and her
lines change with it. She also talks on her own every few minutes and worries when you are hurt or hungry.

## Kiss
Pick **Kiss her** in the menu. Alex talks to you for a few seconds (her lines depend on your friendship),
her eyes turn into hearts, she walks over to you, leans in with closed eyes and puckered lips, and kisses you.
Hearts pop up and you get healed a little. If she gets stuck she steps up to you after ~8 seconds.

## Skin / face
`assets/alexfriend/textures/entity/alex.png` is the faceless skin (hair, bangs, body).
The animated face is drawn in game by `LayerAlexFace` from 16x16 layers in
`textures/entity/face/`: `eyes_*.png`, `mouth_*.png`, `blush_*.png`. Eyes blink (half-lid, closed, sometimes twice),
follow you with their gaze, turn into hearts when she's in love and close during the kiss.
Restyle her by editing the PNGs or by changing `tools/generate_faces.py` and re-running it (needs Pillow).

## Building
GitHub Actions: put `AlexFriendMod.zip` in the repository root and `build.yml` in `.github/workflows/`.
The workflow extracts the zip and builds the jar (Java 8 + 21, Gradle 8.12, RetroFuturaGradle (Forge 1.12.2 14.23.5.2847)).
The jar is uploaded as an artifact named `AlexFriend-jar`.
