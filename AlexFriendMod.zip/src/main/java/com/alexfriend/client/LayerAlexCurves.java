package com.alexfriend.client;

import com.alexfriend.AlexMod;
import com.alexfriend.entity.EntityAlex;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;

/**
 * Rounded body shaping that always stays under her clothes: a full, round bust and hips, built from stacked
 * pixel "discs" (a 4x5 round disc plus a smaller raised disc on top), drawn in exactly her shirt and pants colours
 * (textures/entity/alex_curves.png is generated from her skin by tools/generate_body_curves.py).
 *
 * The bust is attached to the torso and angled slightly outward; the hips are attached to the legs. Both are
 * driven by spring physics (EntityAlex#updateJiggle), so they bounce and sway softly when she walks, jumps
 * and turns, and they follow every pose.
 */
public class LayerAlexCurves implements LayerRenderer<EntityAlex> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(AlexMod.MODID, "textures/entity/alex_curves.png");

    // ---- tuning (model pixels; 1 px = 1/16 block)
    /** Bust centre, measured from the middle of her chest. Larger = further apart / further to the sides. */
    private static final float CHEST_X = 2.7F;
    /** Bust centre height below her shoulders. */
    private static final float CHEST_Y = 5.7F;
    /** How far the first and the raised disc stick out of her torso. */
    private static final float CHEST_OUT_1 = 1.1F;
    private static final float CHEST_OUT_2 = 2.1F;
    /** Outward angle of each breast (radians). */
    private static final float CHEST_ANGLE = 0.22F;

    /** Hip centre relative to the leg pivot (negative = above the hip line). The shape is 2 px behind the leg. */
    private static final float HIP_Y = -1.4F;
    private static final float HIP_OUT_1 = 1.3F;
    private static final float HIP_OUT_2 = 2.3F;
    private static final float HIP_ANGLE = 0.10F;

    private static class Holder extends ModelBase {
        Holder() {
            this.textureWidth = 32;
            this.textureHeight = 16;
        }
    }

    private final RenderAlex renderer;
    private final ModelRenderer chestR, chestL, hipR, hipL;

    public LayerAlexCurves(RenderAlex renderer) {
        this.renderer = renderer;
        Holder h = new Holder();

        // Chest groups sit on the front of the torso (z = -2). Hip groups sit on the back of each leg (z = +2) and are
        // turned around by 180 degrees so the shape's textured "front" faces backward.
        this.chestR = group(h, 0, -CHEST_X, CHEST_Y, -2.0F, 0.0F, 0.0F, 0.0F, CHEST_OUT_1, CHEST_OUT_2);
        this.chestL = group(h, 0, CHEST_X, CHEST_Y, -2.0F, 0.0F, 0.0F, 0.0F, CHEST_OUT_1, CHEST_OUT_2);
        // hips: the group's pivot is the hip joint itself, the shape is offset behind it (z = -2 before the 180 degree turn)
        this.hipR = group(h, 16, 0.0F, 0.0F, 0.0F, 0.0F, HIP_Y, -2.0F, HIP_OUT_1, HIP_OUT_2);
        this.hipL = group(h, 16, 0.0F, 0.0F, 0.0F, 0.0F, HIP_Y, -2.0F, HIP_OUT_1, HIP_OUT_2);

        this.chestR.rotateAngleY = CHEST_ANGLE;      // front (-z) turns toward -x = her right
        this.chestL.rotateAngleY = -CHEST_ANGLE;
        this.hipR.rotateAngleY = (float) Math.PI - HIP_ANGLE;
        this.hipL.rotateAngleY = (float) Math.PI + HIP_ANGLE;
    }

    /**
     * One round shape: a 4 wide x 5 tall pixel disc (rows 2,4,4,4,2 wide) at depth {@code out1}, with a raised
     * 2 x 3 disc on top at depth {@code out2}. All boxes are 2 deep so they reach into the body (no gaps when angled).
     */
    private static ModelRenderer group(ModelBase m, int tileU, float x, float y, float z,
            float ox, float oy, float oz, float out1, float out2) {
        ModelRenderer g = new ModelRenderer(m, tileU, 0);
        g.setRotationPoint(x, y, z);

        // first disc
        g.addChild(box(m, tileU + 0, 1, ox - 2.0F, oy - 1.5F, oz - out1, 4, 3));   // wide middle rows
        g.addChild(box(m, tileU + 1, 0, ox - 1.0F, oy - 2.5F, oz - out1, 2, 1));   // top row
        g.addChild(box(m, tileU + 1, 4, ox - 1.0F, oy + 1.5F, oz - out1, 2, 1));   // bottom row
        // raised disc
        g.addChild(box(m, tileU + 1, 1, ox - 1.0F, oy - 1.5F, oz - out2, 2, 3));
        return g;
    }

    private static ModelRenderer box(ModelBase m, int u, int v, float x, float y, float z, int w, int h) {
        ModelRenderer r = new ModelRenderer(m, u, v);
        r.addBox(x, y, z, w, h, 2);
        return r;
    }

    @Override
    public void doRenderLayer(EntityAlex entity, float limbSwing, float limbSwingAmount, float partialTicks,
            float ageInTicks, float netHeadYaw, float headPitch, float scale) {
        if (entity.isInvisible()) return;

        ModelAlex model = (ModelAlex) this.renderer.getMainModel();
        this.renderer.bindTexture(TEXTURE);

        // spring physics, interpolated between ticks
        float cy = entity.prevChestY + (entity.chestY - entity.prevChestY) * partialTicks;
        float cx = entity.prevChestX + (entity.chestX - entity.prevChestX) * partialTicks;
        float hy = entity.prevHipY + (entity.hipY - entity.prevHipY) * partialTicks;
        float breathe = MathHelper.sin(ageInTicks * 0.09F) * 0.07F;

        // sway pushes one side down while the other goes up; bounce moves both
        this.chestR.rotationPointX = -CHEST_X + cx;
        this.chestL.rotationPointX = CHEST_X + cx;
        this.chestR.rotationPointY = CHEST_Y + cy + breathe - cx * 0.3F;
        this.chestL.rotationPointY = CHEST_Y + cy + breathe + cx * 0.3F;
        // a touch of forward / back roll with the bounce
        this.chestR.rotateAngleX = cy * 0.06F;
        this.chestL.rotateAngleX = cy * 0.06F;

        GlStateManager.pushMatrix();
        model.bipedBody.postRender(scale);
        this.chestR.render(scale);
        this.chestL.render(scale);
        GlStateManager.popMatrix();

        // hips follow the legs, but swing only ~40% as much, so they stay put on her body
        // (the shape is turned 180 degrees about Y, which flips the sign of a rotation about X)
        this.hipR.rotationPointY = hy;
        this.hipL.rotationPointY = hy;
        this.hipR.rotateAngleX = model.bipedRightLeg.rotateAngleX * 0.6F;
        this.hipL.rotateAngleX = model.bipedLeftLeg.rotateAngleX * 0.6F;

        GlStateManager.pushMatrix();
        model.bipedRightLeg.postRender(scale);
        this.hipR.render(scale);
        GlStateManager.popMatrix();

        GlStateManager.pushMatrix();
        model.bipedLeftLeg.postRender(scale);
        this.hipL.render(scale);
        GlStateManager.popMatrix();
    }

    @Override
    public boolean shouldCombineTextures() {
        return false;
    }
}
