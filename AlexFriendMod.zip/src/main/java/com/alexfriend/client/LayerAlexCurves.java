package com.alexfriend.client;

import com.alexfriend.AlexMod;
import com.alexfriend.entity.EntityAlex;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;

/**
 * Subtle body shaping under her clothes: a gentle chest and hip/rear curve, drawn as small shapes in exactly
 * her shirt and pants colours (textures/entity/alex_curves.png is generated from her skin by
 * tools/generate_body_curves.py). They are attached to her torso and legs, so they follow every pose, and they
 * have a very small natural secondary motion when she walks.
 */
public class LayerAlexCurves implements LayerRenderer<EntityAlex> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(AlexMod.MODID, "textures/entity/alex_curves.png");

    private static class Holder extends ModelBase {
        Holder() {
            this.textureWidth = 32;
            this.textureHeight = 16;
        }
    }

    private final RenderAlex renderer;
    private final ModelRenderer chestBaseR, chestBaseL, chestCapR, chestCapL;
    private final ModelRenderer hipBaseR, hipBaseL, hipCapR, hipCapL;

    public LayerAlexCurves(RenderAlex renderer) {
        this.renderer = renderer;
        Holder h = new Holder();

        // body front is z = -2; the shapes stick out less than one pixel, so they only read as soft curves
        this.chestBaseR = box(h, 0, 0, -3.5F, 3.4F, -2.6F, 3, 3, 1);
        this.chestBaseL = box(h, 0, 0, 0.5F, 3.4F, -2.6F, 3, 3, 1);
        this.chestCapR = box(h, 8, 0, -3.0F, 3.9F, -2.95F, 2, 2, 1);
        this.chestCapL = box(h, 8, 0, 1.0F, 3.9F, -2.95F, 2, 2, 1);

        // leg local space: pivot at the hip, back of the leg is z = +2; the shapes straddle the hip line
        this.hipBaseR = box(h, 16, 0, -2.0F, -2.0F, 1.65F, 4, 3, 1);
        this.hipBaseL = box(h, 16, 0, -2.0F, -2.0F, 1.65F, 4, 3, 1);
        this.hipCapR = box(h, 16, 4, -1.5F, -1.5F, 1.9F, 3, 2, 1);
        this.hipCapL = box(h, 16, 4, -1.5F, -1.5F, 1.9F, 3, 2, 1);
    }

    private static ModelRenderer box(ModelBase m, int u, int v, float x, float y, float z, int w, int hgt, int d) {
        ModelRenderer r = new ModelRenderer(m, u, v);
        r.addBox(x, y, z, w, hgt, d);
        return r;
    }

    @Override
    public void doRenderLayer(EntityAlex entity, float limbSwing, float limbSwingAmount, float partialTicks,
            float ageInTicks, float netHeadYaw, float headPitch, float scale) {
        if (entity.isInvisible()) return;

        ModelAlex model = (ModelAlex) this.renderer.getMainModel();
        this.renderer.bindTexture(TEXTURE);

        // tiny, natural secondary motion (a fraction of a pixel): settles with breathing, lags the footsteps
        float breathe = MathHelper.sin(ageInTicks * 0.09F) * 0.06F;
        float chestBounce = MathHelper.sin(limbSwing * 1.3324F + 0.9F) * 0.16F * limbSwingAmount + breathe;
        float hipSway = MathHelper.sin(limbSwing * 0.6662F + 2.2F) * 0.10F * limbSwingAmount;

        this.chestBaseR.rotationPointY = chestBounce * 0.6F;
        this.chestBaseL.rotationPointY = chestBounce * 0.6F;
        this.chestCapR.rotationPointY = chestBounce;
        this.chestCapL.rotationPointY = chestBounce;

        GlStateManager.pushMatrix();
        model.bipedBody.postRender(scale);
        this.chestBaseR.render(scale);
        this.chestBaseL.render(scale);
        this.chestCapR.render(scale);
        this.chestCapL.render(scale);
        GlStateManager.popMatrix();

        this.hipCapR.rotationPointY = hipSway;
        this.hipCapL.rotationPointY = -hipSway;

        GlStateManager.pushMatrix();
        model.bipedRightLeg.postRender(scale);
        this.hipBaseR.render(scale);
        this.hipCapR.render(scale);
        GlStateManager.popMatrix();

        GlStateManager.pushMatrix();
        model.bipedLeftLeg.postRender(scale);
        this.hipBaseL.render(scale);
        this.hipCapL.render(scale);
        GlStateManager.popMatrix();
    }

    @Override
    public boolean shouldCombineTextures() {
        return false;
    }
}
