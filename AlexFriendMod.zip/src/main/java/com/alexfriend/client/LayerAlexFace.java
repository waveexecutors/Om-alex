package com.alexfriend.client;

import java.util.HashMap;
import java.util.Map;

import com.alexfriend.AlexMod;
import com.alexfriend.entity.EntityAlex;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;

/**
 * Draws Alex's animated face on the front of her head as three 16x16 layers: blush, eyes and mouth.
 * Eyes blink (half-lid, closed, half-lid, sometimes twice), glance around and follow the player;
 * the mouth moves while she talks and the expression follows her emotion.
 */
public class LayerAlexFace implements LayerRenderer<EntityAlex> {
    private static final Map<String, ResourceLocation> CACHE = new HashMap<String, ResourceLocation>();

    private final RenderAlex renderer;

    public LayerAlexFace(RenderAlex renderer) {
        this.renderer = renderer;
    }

    private static ResourceLocation tex(String name) {
        ResourceLocation rl = CACHE.get(name);
        if (rl == null) {
            rl = new ResourceLocation(AlexMod.MODID, "textures/entity/face/" + name + ".png");
            CACHE.put(name, rl);
        }
        return rl;
    }

    // ------------------------------------------------------------------ eyes

    /** Gaze: "l" / "c" / "r" (as seen from the front). Follows the local player, else glances around now and then. */
    private static String gaze(EntityAlex e) {
        EntityPlayer pl = Minecraft.getMinecraft().player;
        if (pl != null && pl.getDistanceSq(e) < 144.0D) {
            double dx = pl.posX - e.posX;
            double dz = pl.posZ - e.posZ;
            float yaw = (float) (MathHelper.atan2(dz, dx) * (180.0D / Math.PI)) - 90.0F;
            float rel = MathHelper.wrapDegrees(yaw - e.rotationYawHead);
            if (rel > 14.0F) return "l";   // player is on her right -> pupils to the viewer's left
            if (rel < -14.0F) return "r";
            return "c";
        }
        int slot = (e.ticksExisted / 50 + e.getEntityId() * 7) % 7;
        return slot == 0 ? "l" : (slot == 1 ? "r" : "c");
    }

    /** 0 = eyes open, 1 = half lid, 2 = fully closed. Natural blink every ~4.5s, with an occasional double blink. */
    private static int blinkState(EntityAlex e) {
        int cycle = 90;
        int clock = (e.ticksExisted + e.getEntityId() * 13) % cycle;
        int n = ((e.ticksExisted + e.getEntityId() * 13) / cycle) % 3;
        if (clock < 2) return 1;
        if (clock < 4) return 2;
        if (clock < 6) return 1;
        if (n == 0) {                       // double blink
            if (clock >= 12 && clock < 13) return 1;
            if (clock >= 13 && clock < 15) return 2;
            if (clock >= 15 && clock < 16) return 1;
        }
        return 0;
    }

    private static String eyesFor(EntityAlex e) {
        int act = e.getAction();
        int emo = e.getEmotion();
        int blink = blinkState(e);

        // kissing: heart eyes -> eyes slowly close and stay shut during the kiss
        if (act == EntityAlex.ACT_KISS) {
            int age = e.getActionAge();
            if (age < 7) return (age / 3) % 2 == 0 ? "love_a" : "love_b";
            if (age < 12) return "half";
            if (age < 64) return "kiss";
            return "half";
        }

        // asleep when sitting at night
        if (emo == EntityAlex.EMO_NORMAL && e.isSitting() && (e.world.getWorldTime() % 24000L) > 13000L) {
            return "kiss";
        }

        switch (emo) {
            case EntityAlex.EMO_HAPPY:
                return blink == 2 ? "closed" : "happy";
            case EntityAlex.EMO_LOVE:
                return ((e.ticksExisted / 8) % 2 == 0) ? "love_a" : "love_b";
            case EntityAlex.EMO_SHY:
                return blink == 2 ? "closed" : "shy";
            case EntityAlex.EMO_SAD:
                return blink == 2 ? "closed" : (blink == 1 ? "half" : "sad");
            case EntityAlex.EMO_SURPRISED:
                return "surprised";
            default:
                if (blink == 2) return "closed";
                if (blink == 1) return "half";
                return "open_" + gaze(e);
        }
    }

    // ------------------------------------------------------------------ mouth + blush

    private static String mouthFor(EntityAlex e) {
        int act = e.getAction();
        int emo = e.getEmotion();
        String mouth;

        if (act == EntityAlex.ACT_KISS) {
            int age = e.getActionAge();
            return (age >= 12 && age < 64) ? "pucker" : "smile";
        }

        switch (emo) {
            case EntityAlex.EMO_HAPPY:
                mouth = "grin";
                break;
            case EntityAlex.EMO_SHY:
            case EntityAlex.EMO_LOVE:
                mouth = "smile";
                break;
            case EntityAlex.EMO_SAD:
                mouth = "frown";
                break;
            case EntityAlex.EMO_SURPRISED:
                mouth = "o";
                break;
            default:
                mouth = e.getAffection() >= 20 ? "smile" : "neutral";
                break;
        }
        // mouth moves while she is talking
        if (e.isTalking() && !mouth.equals("o") && (e.ticksExisted / 3) % 2 == 0) {
            mouth = "talk";
        }
        return mouth;
    }

    private static boolean strongBlush(EntityAlex e) {
        if (e.getAction() == EntityAlex.ACT_KISS) return true;
        int emo = e.getEmotion();
        return emo == EntityAlex.EMO_HAPPY || emo == EntityAlex.EMO_SHY || emo == EntityAlex.EMO_LOVE;
    }

    // ------------------------------------------------------------------ drawing

    @Override
    public void doRenderLayer(EntityAlex entity, float limbSwing, float limbSwingAmount, float partialTicks,
            float ageInTicks, float netHeadYaw, float headPitch, float scale) {
        if (entity.isInvisible()) return;

        ModelAlex model = (ModelAlex) this.renderer.getMainModel();

        GlStateManager.pushMatrix();
        model.bipedHead.postRender(scale);
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.disableCull();
        GlStateManager.depthMask(false);

        // each layer sits a hair in front of the one before it
        quad(strongBlush(entity) ? "blush_strong" : "blush_light", -4.02F, scale);
        quad("eyes_" + eyesFor(entity), -4.03F, scale);
        quad("mouth_" + mouthFor(entity), -4.04F, scale);

        GlStateManager.depthMask(true);
        GlStateManager.enableCull();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }

    private void quad(String name, float z, float scale) {
        this.renderer.bindTexture(tex(name));

        // head box spans x -4..4, y -8..0, z -4..4 (model pixels); front face is z = -4
        float x0 = -4.0F * scale, x1 = 4.0F * scale;
        float y0 = -8.0F * scale, y1 = 0.0F;
        float zz = z * scale;

        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = tess.getBuffer();
        buf.begin(7, DefaultVertexFormats.OLDMODEL_POSITION_TEX_NORMAL);
        buf.pos(x0, y0, zz).tex(1.0D, 0.0D).normal(0.0F, 0.0F, -1.0F).endVertex();
        buf.pos(x1, y0, zz).tex(0.0D, 0.0D).normal(0.0F, 0.0F, -1.0F).endVertex();
        buf.pos(x1, y1, zz).tex(0.0D, 1.0D).normal(0.0F, 0.0F, -1.0F).endVertex();
        buf.pos(x0, y1, zz).tex(1.0D, 1.0D).normal(0.0F, 0.0F, -1.0F).endVertex();
        tess.draw();
    }

    @Override
    public boolean shouldCombineTextures() {
        return false;
    }
}
