package com.alexfriend.client;

import com.alexfriend.entity.EntityAlex;

import net.minecraft.client.model.ModelPlayer;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

/** Slim-arm player model with extra idle / walk / action animations. */
public class ModelAlex extends ModelPlayer {

    public ModelAlex() {
        super(0.0F, true);
    }

    @Override
    public void setRotationAngles(float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
            float headPitch, float scaleFactor, Entity entityIn) {
        // Head-spin fix: the raw head yaw can jump by 360 degrees or swing far past her shoulders when the
        // look target changes quickly. Wrap it and keep it inside a natural range.
        netHeadYaw = MathHelper.clamp(MathHelper.wrapDegrees(netHeadYaw), -50.0F, 50.0F);
        headPitch = MathHelper.clamp(headPitch, -30.0F, 30.0F);
        super.setRotationAngles(limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scaleFactor, entityIn);
        if (!(entityIn instanceof EntityAlex)) return;

        EntityAlex alex = (EntityAlex) entityIn;
        // vanilla only resets these in some poses, so clear what the kiss lean may have moved
        this.bipedBody.rotationPointZ = 0.0F;
        this.bipedHead.rotationPointZ = 0.0F;
        float t = ageInTicks;
        float dy = 0.0F;      // whole-body vertical offset in model pixels
        float headDy = 0.0F;  // extra head/shoulder offset (breathing)

        float moving = Math.min(1.0F, limbSwingAmount * 3.0F);
        float idle = 1.0F - moving;

        // ---------- idle: breathing, gentle head look-around, relaxed arm sway
        headDy += MathHelper.sin(t * 0.09F) * 0.22F * idle;
        this.bipedHead.rotateAngleX += MathHelper.sin(t * 0.045F + 1.0F) * 0.02F * idle;
        this.bipedHead.rotateAngleZ += MathHelper.sin(t * 0.04F) * 0.02F * idle;
        this.bipedRightArm.rotateAngleZ += MathHelper.sin(t * 0.07F) * 0.03F * idle;
        this.bipedLeftArm.rotateAngleZ -= MathHelper.sin(t * 0.07F) * 0.03F * idle;
        this.bipedBody.rotateAngleZ = MathHelper.sin(t * 0.045F) * 0.015F * idle;

        // ---------- walking: bouncy step, hip sway, bigger arm swing
        float step = limbSwing * 0.6662F;
        dy -= Math.abs(MathHelper.cos(step)) * limbSwingAmount * 1.1F;
        float sway = MathHelper.cos(step) * 0.14F * limbSwingAmount;
        this.bipedBody.rotateAngleY += sway;
        this.bipedRightArm.rotateAngleX *= 1.2F;
        this.bipedLeftArm.rotateAngleX *= 1.2F;
        this.bipedRightArm.rotateAngleY += sway * 0.5F;
        this.bipedLeftArm.rotateAngleY += sway * 0.5F;

        // ---------- sitting
        boolean sitting = alex.isSitting();
        if (sitting) {
            dy = 10.0F;
            this.bipedRightLeg.rotateAngleX = -1.4137167F;
            this.bipedLeftLeg.rotateAngleX = -1.4137167F;
            this.bipedRightLeg.rotateAngleY = 0.31415927F;
            this.bipedLeftLeg.rotateAngleY = -0.31415927F;
            this.bipedRightLeg.rotateAngleZ = 0.07853982F;
            this.bipedLeftLeg.rotateAngleZ = -0.07853982F;
            this.bipedRightArm.rotateAngleX = -0.6283185F + MathHelper.sin(t * 0.07F) * 0.03F;
            this.bipedLeftArm.rotateAngleX = -0.6283185F + MathHelper.sin(t * 0.07F) * 0.03F;
            this.bipedRightArm.rotateAngleZ = 0.05F;
            this.bipedLeftArm.rotateAngleZ = -0.05F;
            this.bipedBody.rotateAngleY = 0.0F;
        }

        // ---------- action animations
        switch (alex.getAction()) {
            case EntityAlex.ACT_WAVE: {
                this.bipedRightArm.rotateAngleX = -2.8F;
                this.bipedRightArm.rotateAngleZ = 0.3F + MathHelper.sin(t * 0.7F) * 0.4F;
                this.bipedRightArm.rotateAngleY = 0.0F;
                this.bipedHead.rotateAngleZ += 0.1F;
                break;
            }
            case EntityAlex.ACT_DANCE: {
                float s = MathHelper.sin(t * 0.45F);
                float c = MathHelper.cos(t * 0.45F);
                dy = -Math.abs(s) * 1.6F;
                this.bipedBody.rotateAngleY = s * 0.35F;
                this.bipedHead.rotateAngleZ = s * 0.12F;
                this.bipedHead.rotateAngleY = -s * 0.1F;
                this.bipedRightArm.rotateAngleX = -2.4F + s * 0.45F;
                this.bipedRightArm.rotateAngleZ = 0.4F + c * 0.3F;
                this.bipedRightArm.rotateAngleY = 0.0F;
                this.bipedLeftArm.rotateAngleX = -2.4F - s * 0.45F;
                this.bipedLeftArm.rotateAngleZ = -0.4F - c * 0.3F;
                this.bipedLeftArm.rotateAngleY = 0.0F;
                this.bipedRightLeg.rotateAngleX = s * 0.7F;
                this.bipedLeftLeg.rotateAngleX = -s * 0.7F;
                this.bipedRightLeg.rotateAngleY = 0.0F;
                this.bipedLeftLeg.rotateAngleY = 0.0F;
                this.bipedRightLeg.rotateAngleZ = 0.05F;
                this.bipedLeftLeg.rotateAngleZ = -0.05F;
                break;
            }
            case EntityAlex.ACT_HUG: {
                float b = MathHelper.sin(t * 0.2F) * 0.05F;
                this.bipedRightArm.rotateAngleX = -1.4F + b;
                this.bipedLeftArm.rotateAngleX = -1.4F + b;
                this.bipedRightArm.rotateAngleY = -0.55F;
                this.bipedLeftArm.rotateAngleY = 0.55F;
                this.bipedRightArm.rotateAngleZ = 0.0F;
                this.bipedLeftArm.rotateAngleZ = 0.0F;
                this.bipedHead.rotateAngleX += 0.12F;
                this.bipedHead.rotateAngleZ += 0.1F;
                break;
            }
            case EntityAlex.ACT_PAT: {
                this.bipedHead.rotateAngleX = 0.18F;
                this.bipedHead.rotateAngleZ = 0.25F + MathHelper.sin(t * 0.5F) * 0.03F;
                this.bipedRightArm.rotateAngleX = -0.45F;
                this.bipedLeftArm.rotateAngleX = -0.45F;
                this.bipedRightArm.rotateAngleY = -0.5F;
                this.bipedLeftArm.rotateAngleY = 0.5F;
                this.bipedRightArm.rotateAngleZ = 0.0F;
                this.bipedLeftArm.rotateAngleZ = 0.0F;
                break;
            }
            case EntityAlex.ACT_GIFT: {
                this.bipedRightArm.rotateAngleX = -1.25F;
                this.bipedRightArm.rotateAngleY = -0.25F;
                this.bipedRightArm.rotateAngleZ = 0.0F;
                this.bipedLeftArm.rotateAngleX = -0.5F;
                this.bipedLeftArm.rotateAngleY = 0.4F;
                this.bipedHead.rotateAngleX += 0.1F;
                break;
            }
            case EntityAlex.ACT_KISS: {
                // ease in over ~20 ticks, hold, ease out over the last ~14 ticks of the 70-tick action
                float age = alex.getActionAge();
                float k = Math.min(1.0F, age / 20.0F);
                if (age > 56.0F) k = Math.max(0.0F, (70.0F - age) / 14.0F);
                k = k * k * (3.0F - 2.0F * k);

                // lean toward the player: pivot the torso around her hips so nothing detaches
                float lean = 0.16F * k;
                float ls = MathHelper.sin(lean);
                this.bipedBody.rotateAngleX = lean;
                this.bipedBody.rotationPointZ = -12.0F * ls;
                this.bipedHead.rotationPointZ = -12.0F * ls;
                this.bipedRightArm.rotationPointZ = -9.5F * ls;
                this.bipedLeftArm.rotationPointZ = -9.5F * ls;

                // shy little head tilt, chin slightly up
                this.bipedHead.rotateAngleX = -0.12F * k + this.bipedHead.rotateAngleX * (1.0F - k);
                this.bipedHead.rotateAngleZ = 0.14F * k;

                // hands held together in front of her
                this.bipedRightArm.rotateAngleX = -0.85F * k + this.bipedRightArm.rotateAngleX * (1.0F - k);
                this.bipedLeftArm.rotateAngleX = -0.85F * k + this.bipedLeftArm.rotateAngleX * (1.0F - k);
                this.bipedRightArm.rotateAngleY = -0.6F * k;
                this.bipedLeftArm.rotateAngleY = 0.6F * k;
                this.bipedRightArm.rotateAngleZ = 0.0F;
                this.bipedLeftArm.rotateAngleZ = 0.0F;

                // a little foot pop at the moment of the kiss
                if (age > 24.0F && age < 50.0F) {
                    this.bipedLeftLeg.rotateAngleX = -0.35F * k;
                }
                break;
            }
            default:
                break;
        }

        // ---------- apply vertical offsets
        this.bipedHead.rotationPointY = dy + headDy;
        this.bipedBody.rotationPointY = dy;
        this.bipedRightArm.rotationPointY = 2.5F + dy + headDy;
        this.bipedLeftArm.rotationPointY = 2.5F + dy + headDy;
        this.bipedRightLeg.rotationPointY = 12.0F + dy;
        this.bipedLeftLeg.rotationPointY = 12.0F + dy;

        // keep the clothing / hair overlay layers in sync (1.12.2 has no ModelRenderer#copyModelAngles)
        copyAngles(this.bipedHeadwear, this.bipedHead);
        copyAngles(this.bipedBodyWear, this.bipedBody);
        copyAngles(this.bipedLeftArmwear, this.bipedLeftArm);
        copyAngles(this.bipedRightArmwear, this.bipedRightArm);
        copyAngles(this.bipedLeftLegwear, this.bipedLeftLeg);
        copyAngles(this.bipedRightLegwear, this.bipedRightLeg);
    }

    /** Manual equivalent of ModelRenderer#copyModelAngles (added in later MC versions). */
    private static void copyAngles(net.minecraft.client.model.ModelRenderer target, net.minecraft.client.model.ModelRenderer source) {
        target.rotateAngleX = source.rotateAngleX;
        target.rotateAngleY = source.rotateAngleY;
        target.rotateAngleZ = source.rotateAngleZ;
        target.rotationPointX = source.rotationPointX;
        target.rotationPointY = source.rotationPointY;
        target.rotationPointZ = source.rotationPointZ;
    }
}
