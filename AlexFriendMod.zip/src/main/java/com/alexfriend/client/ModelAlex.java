package com.alexfriend.client;

import com.alexfriend.entity.EntityAlex;

import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

/**
 * Slim-arm player model with extra idle / walk / action animations.
 *
 * Head-spin fix: vanilla's ModelBiped does NOT reset every angle each frame (e.g. head roll, leg yaw/roll).
 * The old code used "+=" on those, so the values grew every frame and the head kept rolling. Every angle that
 * is touched here is now reset explicitly at the start of each frame, and nothing accumulates.
 *
 * Smoothness: action poses are blended in and out (EntityAlex#getPoseWeight) and use partial-tick time, so
 * poses no longer pop between animations.
 */
public class ModelAlex extends ModelPlayer {
    private static final int HEAD = 0, BODY = 1, RARM = 2, LARM = 3, RLEG = 4, LLEG = 5;

    private final float[][] base = new float[6][5];

    public ModelAlex() {
        super(0.0F, true);
    }

    private ModelRenderer part(int i) {
        switch (i) {
            case HEAD: return this.bipedHead;
            case BODY: return this.bipedBody;
            case RARM: return this.bipedRightArm;
            case LARM: return this.bipedLeftArm;
            case RLEG: return this.bipedRightLeg;
            default: return this.bipedLeftLeg;
        }
    }

    @Override
    public void setRotationAngles(float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
            float headPitch, float scaleFactor, Entity entityIn) {
        // keep the head inside a natural range and wrapped (no 360 degree jumps)
        netHeadYaw = MathHelper.clamp(MathHelper.wrapDegrees(netHeadYaw), -50.0F, 50.0F);
        headPitch = MathHelper.clamp(headPitch, -30.0F, 30.0F);
        super.setRotationAngles(limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scaleFactor, entityIn);
        if (!(entityIn instanceof EntityAlex)) return;

        EntityAlex alex = (EntityAlex) entityIn;
        float t = ageInTicks;
        float partial = ageInTicks - (float) alex.ticksExisted;

        // ---------- reset everything vanilla leaves untouched, so nothing can accumulate between frames
        this.bipedHead.rotateAngleZ = 0.0F;
        this.bipedHead.rotationPointZ = 0.0F;
        this.bipedBody.rotateAngleX = 0.0F;
        this.bipedBody.rotateAngleY = 0.0F;
        this.bipedBody.rotateAngleZ = 0.0F;
        this.bipedBody.rotationPointZ = 0.0F;
        this.bipedRightArm.rotateAngleY = 0.0F;
        this.bipedLeftArm.rotateAngleY = 0.0F;
        this.bipedRightArm.rotationPointZ = 0.0F;
        this.bipedLeftArm.rotationPointZ = 0.0F;
        this.bipedRightLeg.rotateAngleY = 0.0F;
        this.bipedLeftLeg.rotateAngleY = 0.0F;
        this.bipedRightLeg.rotateAngleZ = 0.0F;
        this.bipedLeftLeg.rotateAngleZ = 0.0F;
        this.bipedRightLeg.rotationPointZ = 0.1F;
        this.bipedLeftLeg.rotationPointZ = 0.1F;

        float dy = 0.0F;      // whole-body vertical offset in model pixels
        float headDy = 0.0F;  // extra head/shoulder offset (breathing)

        float moving = Math.min(1.0F, limbSwingAmount * 3.0F);
        float idle = 1.0F - moving;

        // ---------- idle: breathing, tiny head settle, relaxed arm sway
        headDy += MathHelper.sin(t * 0.09F) * 0.22F * idle;
        this.bipedHead.rotateAngleX += MathHelper.sin(t * 0.045F + 1.0F) * 0.02F * idle;
        this.bipedHead.rotateAngleZ = MathHelper.sin(t * 0.04F) * 0.02F * idle;
        this.bipedRightArm.rotateAngleZ += MathHelper.sin(t * 0.07F) * 0.03F * idle;
        this.bipedLeftArm.rotateAngleZ -= MathHelper.sin(t * 0.07F) * 0.03F * idle;
        this.bipedBody.rotateAngleZ = MathHelper.sin(t * 0.045F) * 0.015F * idle;

        // ---------- walking: bouncy step, hip sway, bigger arm swing
        float step = limbSwing * 0.6662F;
        dy -= Math.abs(MathHelper.cos(step)) * limbSwingAmount * 1.1F;
        float sway = MathHelper.cos(step) * 0.14F * limbSwingAmount;
        this.bipedBody.rotateAngleY = sway;
        this.bipedRightArm.rotateAngleX *= 1.2F;
        this.bipedLeftArm.rotateAngleX *= 1.2F;
        this.bipedRightArm.rotateAngleY = sway * 0.5F;
        this.bipedLeftArm.rotateAngleY = sway * 0.5F;

        // ---------- sitting (eased by the entity so standing up / sitting down is not a pop)
        if (alex.isSitting()) {
            dy = 10.0F;
            this.bipedRightLeg.rotateAngleX = -1.4137167F;
            this.bipedLeftLeg.rotateAngleX = -1.4137167F;
            this.bipedRightLeg.rotateAngleY = 0.31415927F;
            this.bipedLeftLeg.rotateAngleY = -0.31415927F;
            this.bipedRightLeg.rotateAngleZ = 0.07853982F;
            this.bipedLeftLeg.rotateAngleZ = -0.07853982F;
            this.bipedRightArm.rotateAngleX = -0.6283185F + MathHelper.sin(t * 0.07F) * 0.03F;
            this.bipedLeftArm.rotateAngleX = -0.6283185F + MathHelper.sin(t * 0.07F) * 0.03F;
            this.bipedRightArm.rotateAngleZ = 0.05F;
            this.bipedLeftArm.rotateAngleZ = -0.05F;
            this.bipedBody.rotateAngleY = 0.0F;
        }

        applyOffsets(dy, headDy);

        // ---------- action animation, blended on top of the base pose
        int act = alex.getPoseAction();
        float w = alex.getPoseWeight(partial);
        if (act != EntityAlex.ACT_NONE && w > 0.001F) {
            for (int i = 0; i < 6; i++) {
                ModelRenderer p = part(i);
                base[i][0] = p.rotateAngleX;
                base[i][1] = p.rotateAngleY;
                base[i][2] = p.rotateAngleZ;
                base[i][3] = p.rotationPointY;
                base[i][4] = p.rotationPointZ;
            }

            float age = alex.getActionAge() + partial;
            float dyAct = applyAction(act, alex, t, age, dy);
            applyOffsets(dyAct, headDy);

            if (w < 0.999F) {
                for (int i = 0; i < 6; i++) {
                    ModelRenderer p = part(i);
                    p.rotateAngleX = base[i][0] + (p.rotateAngleX - base[i][0]) * w;
                    p.rotateAngleY = base[i][1] + (p.rotateAngleY - base[i][1]) * w;
                    p.rotateAngleZ = base[i][2] + (p.rotateAngleZ - base[i][2]) * w;
                    p.rotationPointY = base[i][3] + (p.rotationPointY - base[i][3]) * w;
                    p.rotationPointZ = base[i][4] + (p.rotationPointZ - base[i][4]) * w;
                }
            }
        }

        // keep the clothing / hair overlay layers in sync (1.12.2 has no ModelRenderer#copyModelAngles)
        copyAngles(this.bipedHeadwear, this.bipedHead);
        copyAngles(this.bipedBodyWear, this.bipedBody);
        copyAngles(this.bipedLeftArmwear, this.bipedLeftArm);
        copyAngles(this.bipedRightArmwear, this.bipedRightArm);
        copyAngles(this.bipedLeftLegwear, this.bipedLeftLeg);
        copyAngles(this.bipedRightLegwear, this.bipedRightLeg);
    }

    private void applyOffsets(float dy, float headDy) {
        this.bipedHead.rotationPointY = dy + headDy;
        this.bipedBody.rotationPointY = dy;
        this.bipedRightArm.rotationPointY = 2.5F + dy + headDy;
        this.bipedLeftArm.rotationPointY = 2.5F + dy + headDy;
        this.bipedRightLeg.rotationPointY = 12.0F + dy;
        this.bipedLeftLeg.rotationPointY = 12.0F + dy;
    }

    /** Sets the full pose for an action (relative to the base pose). Returns the body vertical offset to use. */
    private float applyAction(int act, EntityAlex alex, float t, float age, float dy) {
        switch (act) {
            case EntityAlex.ACT_WAVE: {
                this.bipedRightArm.rotateAngleX = -2.8F;
                this.bipedRightArm.rotateAngleZ = 0.3F + MathHelper.sin(t * 0.7F) * 0.4F;
                this.bipedRightArm.rotateAngleY = 0.0F;
                this.bipedHead.rotateAngleZ += 0.1F;
                break;
            }
            case EntityAlex.ACT_DANCE: {
                float s = MathHelper.sin(t * 0.45F);
                float c = MathHelper.cos(t * 0.45F);
                dy = -Math.abs(s) * 1.6F;
                this.bipedBody.rotateAngleY = s * 0.35F;
                this.bipedHead.rotateAngleZ = s * 0.12F;
                this.bipedHead.rotateAngleY = -s * 0.1F;
                this.bipedRightArm.rotateAngleX = -2.4F + s * 0.45F;
                this.bipedRightArm.rotateAngleZ = 0.4F + c * 0.3F;
                this.bipedRightArm.rotateAngleY = 0.0F;
                this.bipedLeftArm.rotateAngleX = -2.4F - s * 0.45F;
                this.bipedLeftArm.rotateAngleZ = -0.4F - c * 0.3F;
                this.bipedLeftArm.rotateAngleY = 0.0F;
                this.bipedRightLeg.rotateAngleX = s * 0.7F;
                this.bipedLeftLeg.rotateAngleX = -s * 0.7F;
                this.bipedRightLeg.rotateAngleY = 0.0F;
                this.bipedLeftLeg.rotateAngleY = 0.0F;
                this.bipedRightLeg.rotateAngleZ = 0.05F;
                this.bipedLeftLeg.rotateAngleZ = -0.05F;
                break;
            }
            case EntityAlex.ACT_HUG: {
                float b = MathHelper.sin(t * 0.2F) * 0.05F;
                this.bipedRightArm.rotateAngleX = -1.4F + b;
                this.bipedLeftArm.rotateAngleX = -1.4F + b;
                this.bipedRightArm.rotateAngleY = -0.55F;
                this.bipedLeftArm.rotateAngleY = 0.55F;
                this.bipedRightArm.rotateAngleZ = 0.0F;
                this.bipedLeftArm.rotateAngleZ = 0.0F;
                this.bipedHead.rotateAngleX += 0.12F;
                this.bipedHead.rotateAngleZ += 0.1F;
                break;
            }
            case EntityAlex.ACT_PAT: {
                this.bipedHead.rotateAngleX = 0.18F;
                this.bipedHead.rotateAngleZ = 0.25F + MathHelper.sin(t * 0.5F) * 0.03F;
                this.bipedRightArm.rotateAngleX = -0.45F;
                this.bipedLeftArm.rotateAngleX = -0.45F;
                this.bipedRightArm.rotateAngleY = -0.5F;
                this.bipedLeftArm.rotateAngleY = 0.5F;
                this.bipedRightArm.rotateAngleZ = 0.0F;
                this.bipedLeftArm.rotateAngleZ = 0.0F;
                break;
            }
            case EntityAlex.ACT_GIFT: {
                this.bipedRightArm.rotateAngleX = -1.25F;
                this.bipedRightArm.rotateAngleY = -0.25F;
                this.bipedRightArm.rotateAngleZ = 0.0F;
                this.bipedLeftArm.rotateAngleX = -0.5F;
                this.bipedLeftArm.rotateAngleY = 0.4F;
                this.bipedHead.rotateAngleX += 0.1F;
                break;
            }
            case EntityAlex.ACT_KISS: {
                // ease in over ~20 ticks, hold, ease out over the last ~14 ticks of the 70-tick action
                float k = Math.min(1.0F, age / 20.0F);
                if (age > 56.0F) k = Math.max(0.0F, (70.0F - age) / 14.0F);
                k = k * k * (3.0F - 2.0F * k);

                // lean toward the player: pivot the torso around her hips so nothing detaches
                float lean = 0.16F * k;
                float ls = MathHelper.sin(lean);
                this.bipedBody.rotateAngleX = lean;
                this.bipedBody.rotationPointZ = -12.0F * ls;
                this.bipedHead.rotationPointZ = -12.0F * ls;
                this.bipedRightArm.rotationPointZ = -9.5F * ls;
                this.bipedLeftArm.rotationPointZ = -9.5F * ls;

                // shy little head tilt, chin slightly up
                this.bipedHead.rotateAngleX = -0.12F * k + this.bipedHead.rotateAngleX * (1.0F - k);
                this.bipedHead.rotateAngleZ = 0.14F * k;

                // hands held together in front of her
                this.bipedRightArm.rotateAngleX = -0.85F * k + this.bipedRightArm.rotateAngleX * (1.0F - k);
                this.bipedLeftArm.rotateAngleX = -0.85F * k + this.bipedLeftArm.rotateAngleX * (1.0F - k);
                this.bipedRightArm.rotateAngleY = -0.6F * k;
                this.bipedLeftArm.rotateAngleY = 0.6F * k;
                this.bipedRightArm.rotateAngleZ = 0.0F;
                this.bipedLeftArm.rotateAngleZ = 0.0F;

                // a little foot pop around the moment of the kiss (smooth bump, not a switch)
                float pop = MathHelper.sin(MathHelper.clamp((age - 20.0F) / 30.0F, 0.0F, 1.0F) * (float) Math.PI);
                this.bipedLeftLeg.rotateAngleX = -0.35F * pop * k;
                break;
            }
            default:
                break;
        }
        return dy;
    }

    /** Manual equivalent of ModelRenderer#copyModelAngles (added in later MC versions). */
    private static void copyAngles(ModelRenderer target, ModelRenderer source) {
        target.rotateAngleX = source.rotateAngleX;
        target.rotateAngleY = source.rotateAngleY;
        target.rotateAngleZ = source.rotateAngleZ;
        target.rotationPointX = source.rotationPointX;
        target.rotationPointY = source.rotationPointY;
        target.rotationPointZ = source.rotationPointZ;
    }
}
