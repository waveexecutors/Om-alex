package com.alexfriend.client;

import com.alexfriend.AlexMod;
import com.alexfriend.entity.EntityAlex;

import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.layers.LayerHeldItem;
import net.minecraft.util.ResourceLocation;

public class RenderAlex extends RenderLiving<EntityAlex> {
    // alex.png has NO face - the animated face is drawn by LayerAlexFace.
    private static final ResourceLocation TEXTURE = new ResourceLocation(AlexMod.MODID, "textures/entity/alex.png");

    public RenderAlex(RenderManager manager) {
        super(manager, new ModelAlex(), 0.5F);
        this.addLayer(new LayerHeldItem(this));
        this.addLayer(new LayerAlexCurves(this));
        this.addLayer(new LayerAlexFace(this));
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityAlex entity) {
        return TEXTURE;
    }

    @Override
    protected void preRenderCallback(EntityAlex entity, float partialTickTime) {
        float s = 0.9375F;
        GlStateManager.scale(s, s, s);
    }
}
