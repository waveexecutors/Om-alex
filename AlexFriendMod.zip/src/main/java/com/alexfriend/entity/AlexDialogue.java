package com.alexfriend.entity;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/** Everything Alex can say. Tier 0 = new friend, 1 = friend, 2 = best friend. %p = player name. */
public class AlexDialogue {
    private static final Map<String, String[][]> LINES = new HashMap<String, String[][]>();

    private static void L(String key, String[]... tiers) {
        LINES.put(key, tiers);
    }

    private static String[] a(String... s) {
        return s;
    }

    static {
        L("intro", a("Hi! I'm Alex! Want to be friends, %p? Right click me anytime!",
                "Oh, a new face! I'm Alex. I'd love to explore with you, %p!"));
        L("stranger", a("Hi there! I'm already %p's friend, but nice to meet you!",
                "Hello! Sorry, I'm with someone else right now."));
        L("talk",
                a("The world is so big! I hope we find a cave with diamonds.",
                        "Do you like building? I could never decide on a house design.",
                        "I'm still getting used to you, but I think we'll get along."),
                a("Did you know creepers are scared of cats? I read that somewhere.",
                        "I was thinking we should plant a big flower garden together.",
                        "Honestly, adventures are better with you around, %p."),
                a("You're my favorite person in this whole world, %p.",
                        "Whatever we build next, I'm just happy I get to do it with you.",
                        "Sometimes I just like standing next to you and watching the sunset."));
        L("hug",
                a("O-oh! A hug? Okay... *hugs back awkwardly*", "That was nice, thank you."),
                a("Aww, come here! *warm hug*", "Hugs are the best! Thanks, %p!"),
                a("*hugs you tightly* I really needed that. Love you, %p!"));
        L("pat",
                a("H-hey! My hair... but it's okay, I guess.", "Um... that's kind of nice."),
                a("Hehe, that tickles!", "*blushes* You're such a dork, %p."),
                a("*leans into your hand* Don't stop...", "My hair is messy now! ...Do it again."));
        L("come_closer", a("You're too far away! Come closer, %p."));
        L("gift_none", a("Your hand is empty, %p! Hold the gift in your main hand first."));
        L("gift_loved",
                a("WOW! For me?! Thank you so much, %p!", "This is amazing! I love it!"),
                a("You remembered what I like! Thank you, %p!"),
                a("*gasps* You're spoiling me! I love it, I love you, %p!"));
        L("gift_food",
                a("Oh, food! Thank you! *munch*", "Thanks, I was getting hungry!"),
                a("Yum! You always know what I need."));
        L("gift_item",
                a("A gift? Thanks, I'll keep it safe!", "Oh, thank you! That's really thoughtful."),
                a("You got me something? You didn't have to, %p."));
        L("dance",
                a("Okay, okay, watch this!", "I'm not the best dancer, but here goes!"),
                a("Let's dance! Music in your head, go!", "Oooh, my favorite part!"),
                a("Dance with me, %p! Nobody's watching but the sheep!"));
        L("dance_end", a("Phew! That was fun!", "I'm out of breath! Good one!"));
        L("wave", a("Hiii! *waves*", "Hey %p! Over here!"));
        L("compliment",
                a("Oh! Um, thanks. That's nice of you to say.", "You think so? Thank you!"),
                a("Stop it, you're making me blush!", "Aww, you're sweet, %p."),
                a("You always know what to say to make my day. Thank you, %p.",
                        "Hehe... you're way cooler than me, though."));
        L("joke",
                a("Why did the creeper cross the road?|To get to the other SSSSide!",
                        "What do you call a sleeping Enderman?|A teleport-nap!"),
                a("What's a skeleton's favorite instrument?|The trom-bone!",
                        "Why can't you trust stairs?|They're always up to something!"),
                a("Why did the zombie go to therapy?|He had too much emotional baggage... rotten flesh, get it?",
                        "What did the pickaxe say to the stone?|It's been a real rock-ing time!"));
        L("snack", a("Here, I made this for you! Eat up!", "I found something to snack on. Share?"));
        L("snack_locked", a("I don't know you well enough to share my snacks yet. Let's talk more!"));
        L("snack_wait", a("I just gave you something! Give me a bit to find more food."));
        L("flower", a("I found this flower... it made me think of you.", "Here! Picked it just now, for you."));
        L("flower_wait", a("I'm all out of flowers for now! Give me a minute to find more."));
        L("follow", a("Okay! I'll follow you!", "Lead the way, %p!"));
        L("stay", a("Okay, I'll wait right here.", "I'll stay put. Don't be gone too long!"));
        L("sit", a("*sits down* Ahh, a break sounds great.", "Resting time!"));
        L("stand", a("Alright, back on my feet!", "Ready to go again!"));
        L("come", a("On my way!", "Coming, %p!"));
        L("kiss_1",
                a("Um... a kiss? O-okay... I'm kind of nervous, just don't laugh at me!",
                        "A k-kiss?! Wow, okay... give me a second, my heart is racing!"),
                a("Aww, you want a kiss? Hehe, you're so sweet, %p.",
                        "A kiss? My heart is beating so fast right now..."),
                a("Of course, my love. I've been waiting for this all day, %p.",
                        "Come here, you. I could never say no to that."));
        L("kiss_2",
                a("Stay right there... I'm coming!", "Okay, deep breath... here I come!"),
                a("Close your eyes... I'm coming over!", "Don't move! I'm on my way, %p."),
                a("Don't move, I'm coming to you, %p~", "Close your eyes for me... almost there."));
        L("kiss_after",
                a("*blushes* T-that was... thank you, %p.", "Ahh, my face is so hot right now!"),
                a("Mwah~ That was perfect. *giggles*", "Hehe... my cheeks are burning, %p!"),
                a("*smiles softly* I love you, %p. Now and always.",
                        "Mmm... I could stay like this forever, %p."));
        L("hurt", a("Ouch! That hurt!", "Hey! Careful!", "Ow! What was that?!"));
        L("death", a("...I'll be back... please be careful, %p..."));
        L("levelup1", a("You know, %p, I think we're becoming real friends!"));
        L("levelup2", a("%p... you're my best friend. I really mean it. Thank you for everything."));
        L("idle_day",
                a("Nice weather today. Anything we should do?", "I love the daytime. Everything looks so bright!"),
                a("Want to go mining later, %p? I have a good feeling about it.", "The grass looks great today."),
                a("Just thinking how lucky I am to have you around, %p."));
        L("idle_night",
                a("It's getting dark. Stay close, okay?", "I hear zombies out there..."),
                a("Night time already? Better stay near a torch!", "Don't wander off, %p!"),
                a("I'll protect you from the monsters, %p. Promise!"));
        L("idle_rain", a("Ugh, the rain is so cold...", "Rainy day. Great for staying inside and building."),
                a("Rain makes me sleepy. Can we sit by a fire, %p?"));
        L("owner_low_hp", a("%p, you're hurt! Please be careful!", "Your health is really low! Eat something or rest!"));
        L("owner_hungry", a("%p, your stomach is growling! Eat something!", "You should eat. I don't want you to starve!"));
    }

    public static String pick(String key, int affection, Random rand, String playerName) {
        String[][] tiers = LINES.get(key);
        if (tiers == null || tiers.length == 0) return "...";
        int tier = affection >= 60 ? 2 : (affection >= 20 ? 1 : 0);
        if (tier >= tiers.length) tier = tiers.length - 1;
        String[] arr = tiers[tier];
        return arr[rand.nextInt(arr.length)].replace("%p", playerName);
    }
}
