package com.alexfriend.entity;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import javax.annotation.Nullable;

import com.alexfriend.AlexMod;
import com.alexfriend.network.PacketOpenMenu;

import net.minecraft.block.Block;
import net.minecraft.block.BlockFlower;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.ai.EntityAIFollowOwner;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAISit;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWanderAvoidWater;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.passive.EntityTameable;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

public class EntityAlex extends EntityTameable {
    // emotions (drive the animated face)
    public static final int EMO_NORMAL = 0;
    public static final int EMO_HAPPY = 1;
    public static final int EMO_SHY = 2;
    public static final int EMO_SAD = 3;
    public static final int EMO_SURPRISED = 4;
    public static final int EMO_LOVE = 5;

    // body animations
    public static final int ACT_NONE = 0;
    public static final int ACT_WAVE = 1;
    public static final int ACT_DANCE = 2;
    public static final int ACT_HUG = 3;
    public static final int ACT_PAT = 4;
    public static final int ACT_GIFT = 5;
    public static final int ACT_KISS = 6;

    private static final DataParameter<Integer> EMOTION = EntityDataManager.createKey(EntityAlex.class, DataSerializers.VARINT);
    private static final DataParameter<Boolean> TALKING = EntityDataManager.createKey(EntityAlex.class, DataSerializers.BOOLEAN);
    private static final DataParameter<Integer> ACTION = EntityDataManager.createKey(EntityAlex.class, DataSerializers.VARINT);
    private static final DataParameter<Integer> AFFECTION = EntityDataManager.createKey(EntityAlex.class, DataSerializers.VARINT);

    private static class Pending {
        final UUID player;
        final String text;
        final int emotion;
        final int emotionTicks;
        int ticks;

        Pending(UUID player, String text, int ticks, int emotion, int emotionTicks) {
            this.player = player;
            this.text = text;
            this.ticks = ticks;
            this.emotion = emotion;
            this.emotionTicks = emotionTicks;
        }
    }

    private final List<Pending> pending = new ArrayList<Pending>();
    private int emotionTicks;
    private int talkTicks;
    private int actionTicks;
    private int heldTicks;
    private int idleChatTimer = 600;
    private int careCooldown;
    private int hurtChatCooldown;
    private long nextAffectionTime;
    private long nextSnack;
    private long nextFlower;
    private boolean staying;
    private EntityPlayer actionTarget;

    // kiss sequence: 0 = off, 1 = talking, 2 = walking to the player, 3 = kissing
    private int kissPhase;
    private int kissTick;
    private EntityPlayer kissTarget;
    /** Ticks the current action has been playing (kept on both client and server, drives the animations). */
    private int actionAge;
    private int lastActionSeen;

    public EntityAlex(World world) {
        super(world);
        this.setSize(0.6F, 1.8F);
        this.setDropChance(EntityEquipmentSlot.MAINHAND, 0.0F);
        this.enablePersistence();
    }

    @Override
    protected void initEntityAI() {
        this.aiSit = new EntityAISit(this);
        this.tasks.addTask(0, new EntityAISwimming(this));
        this.tasks.addTask(1, new AIKiss(this));
        this.tasks.addTask(1, new AIBusy(this));
        this.tasks.addTask(2, this.aiSit);
        this.tasks.addTask(3, new AIFollow(this, 1.05D, 6.0F, 2.5F));
        this.tasks.addTask(4, new AIWander(this, 0.8D));
        this.tasks.addTask(5, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
        this.tasks.addTask(6, new EntityAILookIdle(this));
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0D);
        this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.3D);
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.dataManager.register(EMOTION, 0);
        this.dataManager.register(TALKING, false);
        this.dataManager.register(ACTION, 0);
        this.dataManager.register(AFFECTION, 0);
    }

    // ------------------------------------------------------------------ AI helpers

    static class AIFollow extends EntityAIFollowOwner {
        private final EntityAlex alex;

        AIFollow(EntityAlex alex, double speed, float minDist, float maxDist) {
            super(alex, speed, minDist, maxDist);
            this.alex = alex;
        }

        @Override
        public boolean shouldExecute() {
            return !alex.staying && super.shouldExecute();
        }

        @Override
        public boolean shouldContinueExecuting() {
            return !alex.staying && super.shouldContinueExecuting();
        }
    }

    static class AIWander extends EntityAIWanderAvoidWater {
        private final EntityAlex alex;

        AIWander(EntityAlex alex, double speed) {
            super(alex, speed);
            this.alex = alex;
        }

        @Override
        public boolean shouldExecute() {
            return !alex.staying && !alex.isSitting() && super.shouldExecute();
        }
    }

    /** Keeps Alex still and facing the player while an action animation plays. */
    static class AIBusy extends EntityAIBase {
        private final EntityAlex alex;

        AIBusy(EntityAlex alex) {
            this.alex = alex;
            this.setMutexBits(3);
        }

        @Override
        public boolean shouldExecute() {
            return alex.actionTicks > 0 && alex.kissPhase == 0;
        }

        @Override
        public boolean shouldContinueExecuting() {
            return alex.actionTicks > 0 && alex.kissPhase == 0;
        }

        @Override
        public void startExecuting() {
            alex.getNavigator().clearPath();
        }

        @Override
        public void updateTask() {
            EntityPlayer t = alex.actionTarget;
            if (t != null && alex.getAction() != ACT_DANCE) {
                alex.getLookHelper().setLookPositionWithEntity(t, 30.0F, 30.0F);
            }
        }
    }

    /** Drives the kiss sequence (talk -> walk to the player -> kiss). Overrides follow / wander / sit while active. */
    static class AIKiss extends EntityAIBase {
        private final EntityAlex alex;

        AIKiss(EntityAlex alex) {
            this.alex = alex;
            this.setMutexBits(3);
        }

        @Override
        public boolean shouldExecute() {
            return alex.kissPhase != 0;
        }

        @Override
        public boolean shouldContinueExecuting() {
            return alex.kissPhase != 0;
        }

        @Override
        public boolean isInterruptible() {
            return false;
        }

        @Override
        public void startExecuting() {
            alex.getNavigator().clearPath();
        }

        @Override
        public void updateTask() {
            alex.tickKiss();
        }
    }

    // ------------------------------------------------------------------ accessors

    public int getEmotion() {
        return this.dataManager.get(EMOTION);
    }

    public boolean isTalking() {
        return this.dataManager.get(TALKING);
    }

    public int getAction() {
        return this.dataManager.get(ACTION);
    }

    public int getAffection() {
        return this.dataManager.get(AFFECTION);
    }

    /** How many ticks the current body action has been running (0 when idle). */
    public int getActionAge() {
        return actionAge;
    }

    /** Slower head turning so her head never whips around. */
    public int getHorizontalFaceSpeed() {
        return 5;
    }

    public int getVerticalFaceSpeed() {
        return 5;
    }

    public boolean isStaying() {
        return staying;
    }

    @Override
    public String getName() {
        return this.hasCustomName() ? this.getCustomNameTag() : "Alex";
    }

    @Override
    public float getEyeHeight() {
        return 1.62F;
    }

    @Override
    public EntityAgeable createChild(EntityAgeable other) {
        return null;
    }

    @Override
    public boolean isBreedingItem(ItemStack stack) {
        return false;
    }

    @Override
    @Nullable
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_PLAYER_HURT;
    }

    @Override
    @Nullable
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_PLAYER_DEATH;
    }

    private boolean isOwner(EntityPlayer p) {
        UUID id = this.getOwnerId();
        return id != null && id.equals(p.getUniqueID());
    }

    @Nullable
    private EntityPlayer getOwnerPlayer() {
        UUID id = this.getOwnerId();
        if (id == null) return null;
        return this.world.getPlayerEntityByUUID(id);
    }

    // ------------------------------------------------------------------ interaction

    @Override
    public boolean processInteract(EntityPlayer player, EnumHand hand) {
        if (hand != EnumHand.MAIN_HAND) return false;
        if (this.world.isRemote) return true;

        if (!this.isTamed()) {
            this.setTamed(true);
            this.setOwnerId(player.getUniqueID());
            this.dataManager.set(AFFECTION, 5);
            this.actionTarget = player;
            startAction(ACT_WAVE, 50);
            hearts(7);
            say(player, AlexDialogue.pick("intro", 0, this.rand, player.getName()), 8, EMO_HAPPY, 120);
        } else if (isOwner(player)) {
            if (player instanceof EntityPlayerMP) {
                AlexMod.network.sendTo(new PacketOpenMenu(this.getEntityId()), (EntityPlayerMP) player);
            }
        } else {
            say(player, AlexDialogue.pick("stranger", 0, this.rand, player.getName()), 4, EMO_NORMAL, 60);
        }
        return true;
    }

    public void performAction(EntityPlayer p, int a) {
        if (this.world.isRemote || !isOwner(p)) return;
        this.actionTarget = p;
        int aff = getAffection();

        switch (a) {
            case AlexActions.CHAT:
                react(p, "talk", -1, 0, ACT_NONE, 0, 1, false);
                break;

            case AlexActions.HUG:
                if (this.getDistanceSq(p) > 9.0D) {
                    react(p, "come_closer", EMO_SHY, 40, ACT_NONE, 0, 0, false);
                    break;
                }
                standUp();
                react(p, "hug", EMO_HAPPY, 100, ACT_HUG, 50, 3, false);
                p.heal(2.0F);
                hearts(8);
                break;

            case AlexActions.HEADPAT:
                if (this.getDistanceSq(p) > 9.0D) {
                    react(p, "come_closer", EMO_SHY, 40, ACT_NONE, 0, 0, false);
                    break;
                }
                react(p, "pat", EMO_SHY, 110, ACT_PAT, 50, 2, false);
                hearts(4);
                break;

            case AlexActions.GIFT:
                handleGift(p);
                break;

            case AlexActions.DANCE:
                standUp();
                react(p, "dance", EMO_HAPPY, 170, ACT_DANCE, 160, 2, false);
                say(p, AlexDialogue.pick("dance_end", aff, this.rand, p.getName()), 170, EMO_HAPPY, 60);
                break;

            case AlexActions.WAVE:
                react(p, "wave", EMO_HAPPY, 60, ACT_WAVE, 50, 1, false);
                break;

            case AlexActions.COMPLIMENT:
                react(p, "compliment", EMO_SHY, 100, ACT_NONE, 0, 2, false);
                break;

            case AlexActions.JOKE:
                react(p, "joke", EMO_HAPPY, 100, ACT_NONE, 0, 1, false);
                break;

            case AlexActions.SNACK: {
                long now = this.world.getTotalWorldTime();
                if (aff < 10) {
                    react(p, "snack_locked", EMO_SHY, 60, ACT_NONE, 0, 0, false);
                } else if (now < nextSnack) {
                    react(p, "snack_wait", EMO_NORMAL, 40, ACT_NONE, 0, 0, false);
                } else {
                    nextSnack = now + 6000L;
                    ItemStack[] snacks = {new ItemStack(Items.BREAD), new ItemStack(Items.APPLE),
                            new ItemStack(Items.COOKIE, 2), new ItemStack(Items.BAKED_POTATO)};
                    ItemStack snack = snacks[this.rand.nextInt(snacks.length)];
                    showHeld(snack, 45);
                    giveToPlayer(p, snack.copy());
                    react(p, "snack", EMO_HAPPY, 80, ACT_GIFT, 45, 1, false);
                }
                break;
            }

            case AlexActions.FLOWER: {
                long now = this.world.getTotalWorldTime();
                if (now < nextFlower) {
                    react(p, "flower_wait", EMO_NORMAL, 40, ACT_NONE, 0, 0, false);
                } else {
                    nextFlower = now + 1200L;
                    ItemStack flower = this.rand.nextInt(4) == 0
                            ? new ItemStack(Blocks.YELLOW_FLOWER)
                            : new ItemStack(Blocks.RED_FLOWER, 1, this.rand.nextInt(9));
                    showHeld(flower, 45);
                    giveToPlayer(p, flower.copy());
                    react(p, "flower", EMO_SHY, 100, ACT_GIFT, 45, 2, false);
                    hearts(5);
                }
                break;
            }

            case AlexActions.FOLLOW:
                staying = false;
                standUp();
                react(p, "follow", EMO_HAPPY, 50, ACT_NONE, 0, 0, false);
                break;

            case AlexActions.STAY:
                staying = true;
                standUp();
                this.getNavigator().clearPath();
                react(p, "stay", EMO_NORMAL, 40, ACT_NONE, 0, 0, false);
                break;

            case AlexActions.SIT:
                if (this.isSitting()) {
                    standUp();
                    react(p, "stand", EMO_HAPPY, 40, ACT_NONE, 0, 0, false);
                } else {
                    this.getNavigator().clearPath();
                    this.aiSit.setSitting(true);
                    this.setSitting(true);
                    this.isJumping = false;
                    react(p, "sit", EMO_NORMAL, 40, ACT_NONE, 0, 0, false);
                }
                break;

            case AlexActions.KISS:
                if (kissPhase == 0) startKiss(p);
                break;

            case AlexActions.COME:
                standUp();
                staying = false;
                Vec3d look = p.getLookVec();
                this.getNavigator().clearPath();
                this.setPositionAndUpdate(p.posX + look.x * 1.6D, p.posY, p.posZ + look.z * 1.6D);
                this.fallDistance = 0.0F;
                react(p, "come", EMO_HAPPY, 50, ACT_WAVE, 30, 0, false);
                break;

            default:
                break;
        }
    }

    // ------------------------------------------------------------------ kiss

    private void startKiss(EntityPlayer p) {
        standUp();
        this.dataManager.set(ACTION, ACT_NONE);   // cut any other body animation first
        this.actionTicks = 0;
        this.kissTarget = p;
        this.actionTarget = p;
        this.kissPhase = 1;
        this.kissTick = 0;
        this.getNavigator().clearPath();
        int aff = getAffection();
        setEmotion(EMO_SHY, 90);
        say(p, AlexDialogue.pick("kiss_1", aff, this.rand, p.getName()), 4, EMO_SHY, 60);
        say(p, AlexDialogue.pick("kiss_2", aff, this.rand, p.getName()), 46, EMO_LOVE, 80);
    }

    private void endKiss() {
        this.kissPhase = 0;
        this.kissTick = 0;
        this.kissTarget = null;
        if (getAction() == ACT_KISS) {
            this.dataManager.set(ACTION, ACT_NONE);
            this.actionTicks = 0;
        }
    }

    private void faceTarget(EntityPlayer p) {
        double dx = p.posX - this.posX;
        double dz = p.posZ - this.posZ;
        float yaw = (float) (MathHelper.atan2(dz, dx) * (180.0D / Math.PI)) - 90.0F;
        this.rotationYaw = yaw;
        this.renderYawOffset = yaw;
        this.rotationYawHead = yaw;
    }

    /** Called every tick (server) by AIKiss while a kiss is in progress. */
    void tickKiss() {
        EntityPlayer p = this.kissTarget;
        if (p == null || p.isDead || this.isDead || p.world != this.world) {
            endKiss();
            return;
        }
        kissTick++;
        this.getLookHelper().setLookPositionWithEntity(p, 30.0F, 30.0F);

        switch (kissPhase) {
            case 1: // she talks first
                this.getNavigator().clearPath();
                if (kissTick >= 90) {
                    kissPhase = 2;
                    kissTick = 0;
                    setEmotion(EMO_LOVE, 400);
                }
                break;

            case 2: { // walks over to the player
                double dx = p.posX - this.posX;
                double dz = p.posZ - this.posZ;
                double flat = Math.sqrt(dx * dx + dz * dz);
                if (flat <= 0.95D && Math.abs(p.posY - this.posY) < 1.0D) {
                    this.getNavigator().clearPath();
                    kissPhase = 3;
                    kissTick = 0;
                    break;
                }
                if (kissTick % 5 == 1) {
                    this.getNavigator().tryMoveToEntityLiving(p, 1.2D);
                }
                if (kissTick > 160 || flat > 24.0D) { // stuck or far away: step up to the player
                    double yawRad = Math.toRadians(p.rotationYaw);
                    this.getNavigator().clearPath();
                    this.setPositionAndUpdate(p.posX - Math.sin(yawRad) * 0.9D, p.posY, p.posZ + Math.cos(yawRad) * 0.9D);
                    this.fallDistance = 0.0F;
                    kissPhase = 3;
                    kissTick = 0;
                }
                break;
            }

            case 3: // the kiss
                this.getNavigator().clearPath();
                faceTarget(p);
                if (kissTick == 1) {
                    startAction(ACT_KISS, 70);
                    setEmotion(EMO_LOVE, 40);
                }
                if (kissTick == 24) {
                    heartsAt((this.posX + p.posX) / 2.0D, this.posY + 1.9D, (this.posZ + p.posZ) / 2.0D, 14);
                    this.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 0.8F, 1.7F);
                    p.heal(4.0F);
                    addAffection(p, 5, true);
                } else if (kissTick == 38) {
                    heartsAt((this.posX + p.posX) / 2.0D, this.posY + 2.0D, (this.posZ + p.posZ) / 2.0D, 6);
                }
                if (kissTick >= 70) {
                    say(p, AlexDialogue.pick("kiss_after", getAffection(), this.rand, p.getName()), 2, EMO_SHY, 160);
                    setEmotion(EMO_SHY, 160);
                    endKiss();
                }
                break;

            default:
                endKiss();
                break;
        }
    }

    private void heartsAt(double x, double y, double z, int count) {
        if (this.world instanceof WorldServer) {
            ((WorldServer) this.world).spawnParticle(EnumParticleTypes.HEART, x, y, z, count, 0.35D, 0.2D, 0.35D, 0.02D);
        }
    }

    private void standUp() {
        if (this.isSitting()) {
            this.aiSit.setSitting(false);
            this.setSitting(false);
        }
    }

    private void handleGift(EntityPlayer p) {
        ItemStack held = p.getHeldItemMainhand();
        if (held.isEmpty()) {
            react(p, "gift_none", EMO_NORMAL, 40, ACT_NONE, 0, 0, false);
            return;
        }
        Item item = held.getItem();
        String key;
        int gain;
        if (isLoved(held)) {
            key = "gift_loved";
            gain = 6;
        } else if (item instanceof ItemFood) {
            key = "gift_food";
            gain = 3;
        } else {
            key = "gift_item";
            gain = 2;
        }
        ItemStack shown = held.copy();
        shown.setCount(1);
        if (item instanceof ItemFood) {
            this.heal((float) ((ItemFood) item).getHealAmount(shown));
        }
        if (!p.capabilities.isCreativeMode) {
            held.shrink(1);
        }
        standUp();
        showHeld(shown, 60);
        react(p, key, EMO_HAPPY, 120, ACT_GIFT, 60, gain, true);
        hearts(key.equals("gift_loved") ? 9 : 5);
    }

    private static boolean isLoved(ItemStack s) {
        Item i = s.getItem();
        return i == Items.DIAMOND || i == Items.EMERALD || i == Items.CAKE || i == Items.GOLDEN_APPLE
                || i == Items.COOKIE || Block.getBlockFromItem(i) instanceof BlockFlower;
    }

    private void giveToPlayer(EntityPlayer p, ItemStack stack) {
        if (!p.inventory.addItemStackToInventory(stack)) {
            p.dropItem(stack, false);
        }
    }

    private void showHeld(ItemStack stack, int ticks) {
        ItemStack one = stack.copy();
        one.setCount(1);
        this.setItemStackToSlot(EntityEquipmentSlot.MAINHAND, one);
        this.heldTicks = ticks;
    }

    private void hearts(int count) {
        if (this.world instanceof WorldServer) {
            ((WorldServer) this.world).spawnParticle(EnumParticleTypes.HEART, this.posX, this.posY + 1.9D, this.posZ,
                    count, 0.4D, 0.25D, 0.4D, 0.02D);
        }
    }

    // ------------------------------------------------------------------ chat + emotions

    /** Common reaction: animation, face, affection and an automatic chat reply. */
    private void react(EntityPlayer p, String key, int emotion, int emoTicks, int act, int actTicks, int gain,
            boolean forceGain) {
        if (act != ACT_NONE) startAction(act, actTicks);
        if (emotion >= 0) setEmotion(emotion, emoTicks);

        String line = AlexDialogue.pick(key, getAffection(), this.rand, p.getName());
        int bar = line.indexOf('|');
        if (bar > 0) {
            say(p, line.substring(0, bar), 12, emotion, emoTicks);
            say(p, line.substring(bar + 1), 75, EMO_HAPPY, 80);
        } else {
            say(p, line, 12, emotion, emoTicks);
        }
        addAffection(p, gain, forceGain);
    }

    private void addAffection(EntityPlayer p, int amount, boolean force) {
        if (amount <= 0) return;
        long now = this.world.getTotalWorldTime();
        if (!force && now < nextAffectionTime) return;
        nextAffectionTime = now + 60L;
        int before = getAffection();
        int after = Math.min(100, before + amount);
        this.dataManager.set(AFFECTION, after);
        if (before < 20 && after >= 20) {
            say(p, AlexDialogue.pick("levelup1", after, this.rand, p.getName()), 100, EMO_HAPPY, 100);
        } else if (before < 60 && after >= 60) {
            say(p, AlexDialogue.pick("levelup2", after, this.rand, p.getName()), 100, EMO_SHY, 120);
        }
    }

    public void say(EntityPlayer p, String text, int delay, int emotion, int emoTicks) {
        pending.add(new Pending(p.getUniqueID(), text, Math.max(1, delay), emotion, emoTicks));
    }

    private void deliver(Pending pd) {
        EntityPlayer p = this.world.getPlayerEntityByUUID(pd.player);
        if (p == null) return;
        ITextComponent msg = new TextComponentString("<Alex> ");
        msg.getStyle().setColor(TextFormatting.LIGHT_PURPLE);
        ITextComponent body = new TextComponentString(pd.text);
        body.getStyle().setColor(TextFormatting.WHITE);
        msg.appendSibling(body);
        p.sendMessage(msg);
        this.talkTicks = Math.min(120, 20 + pd.text.length() * 2);
        this.dataManager.set(TALKING, true);
        if (pd.emotion >= 0) setEmotion(pd.emotion, pd.emotionTicks);
    }

    private void setEmotion(int emotion, int ticks) {
        this.dataManager.set(EMOTION, emotion);
        this.emotionTicks = ticks;
    }

    private void startAction(int act, int ticks) {
        this.dataManager.set(ACTION, act);
        this.actionTicks = ticks;
        this.getNavigator().clearPath();
    }

    // ------------------------------------------------------------------ ticking

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        int curAct = getAction();
        if (curAct != lastActionSeen) {
            lastActionSeen = curAct;
            actionAge = 0;
        }
        if (curAct != ACT_NONE) actionAge++;
        if (!this.world.isRemote) {
            serverTick();
        }
    }

    private void serverTick() {
        if (emotionTicks > 0 && --emotionTicks == 0) {
            this.dataManager.set(EMOTION, EMO_NORMAL);
        }
        if (talkTicks > 0 && --talkTicks == 0) {
            this.dataManager.set(TALKING, false);
        }
        if (actionTicks > 0) {
            if (getAction() == ACT_DANCE && actionTicks % 12 == 0 && this.world instanceof WorldServer) {
                ((WorldServer) this.world).spawnParticle(EnumParticleTypes.NOTE, this.posX, this.posY + 2.1D,
                        this.posZ, 1, 0.3D, 0.1D, 0.3D, 1.0D);
            }
            if (--actionTicks == 0) {
                this.dataManager.set(ACTION, ACT_NONE);
                this.actionTarget = null;
            }
        }
        if (heldTicks > 0 && --heldTicks == 0) {
            this.setItemStackToSlot(EntityEquipmentSlot.MAINHAND, ItemStack.EMPTY);
        }
        if (hurtChatCooldown > 0) hurtChatCooldown--;
        if (careCooldown > 0) careCooldown--;

        Iterator<Pending> it = pending.iterator();
        while (it.hasNext()) {
            Pending pd = it.next();
            if (--pd.ticks <= 0) {
                it.remove();
                deliver(pd);
            }
        }

        if (this.isTamed()) {
            EntityPlayer owner = getOwnerPlayer();
            if (owner != null && this.getDistanceSq(owner) < 400.0D) {
                // she worries when you are in trouble
                if (careCooldown <= 0 && this.ticksExisted % 40 == 0
                        && (owner.getHealth() <= 4.0F || owner.getFoodStats().getFoodLevel() <= 3)) {
                    careCooldown = 1800;
                    String key = owner.getHealth() <= 4.0F ? "owner_low_hp" : "owner_hungry";
                    say(owner, AlexDialogue.pick(key, getAffection(), this.rand, owner.getName()), 2, EMO_SAD, 100);
                }
                // and chats about the world every few minutes
                if (--idleChatTimer <= 0) {
                    idleChatTimer = 2400 + this.rand.nextInt(3600);
                    String key;
                    if (owner.getHealth() <= 6.0F) key = "owner_low_hp";
                    else if (owner.getFoodStats().getFoodLevel() <= 6) key = "owner_hungry";
                    else if (this.world.isRaining()) key = "idle_rain";
                    else if (!this.world.isDaytime()) key = "idle_night";
                    else key = "idle_day";
                    say(owner, AlexDialogue.pick(key, getAffection(), this.rand, owner.getName()), 2, EMO_NORMAL, 60);
                }
            }
        }
    }

    @Override
    public boolean attackEntityFrom(DamageSource source, float amount) {
        boolean hurt = super.attackEntityFrom(source, amount);
        if (hurt && !this.world.isRemote) {
            if (kissPhase != 0) endKiss();
            standUp();
            setEmotion(EMO_SURPRISED, 40);
            EntityPlayer owner = getOwnerPlayer();
            if (owner != null && hurtChatCooldown <= 0 && this.getHealth() > 0.0F) {
                hurtChatCooldown = 100;
                say(owner, AlexDialogue.pick("hurt", getAffection(), this.rand, owner.getName()), 4, EMO_SAD, 80);
            }
        }
        return hurt;
    }

    @Override
    public void onDeath(DamageSource cause) {
        if (!this.world.isRemote) {
            EntityPlayer owner = getOwnerPlayer();
            if (owner != null) {
                ITextComponent msg = new TextComponentString("<Alex> ");
                msg.getStyle().setColor(TextFormatting.LIGHT_PURPLE);
                ITextComponent body = new TextComponentString(
                        AlexDialogue.pick("death", getAffection(), this.rand, owner.getName()));
                body.getStyle().setColor(TextFormatting.WHITE);
                msg.appendSibling(body);
                owner.sendMessage(msg);
            }
        }
        super.onDeath(cause);
    }

    // ------------------------------------------------------------------ saving

    @Override
    public void writeEntityToNBT(NBTTagCompound tag) {
        super.writeEntityToNBT(tag);
        tag.setInteger("Affection", getAffection());
        tag.setBoolean("Staying", staying);
        tag.setLong("NextSnack", nextSnack);
        tag.setLong("NextFlower", nextFlower);
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound tag) {
        super.readEntityFromNBT(tag);
        this.dataManager.set(AFFECTION, tag.getInteger("Affection"));
        staying = tag.getBoolean("Staying");
        nextSnack = tag.getLong("NextSnack");
        nextFlower = tag.getLong("NextFlower");
    }
}
