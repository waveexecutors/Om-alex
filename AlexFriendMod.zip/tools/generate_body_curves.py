#!/usr/bin/env python3
"""Builds textures/entity/alex_curves.png, the texture of Alex's subtle body shaping.

It reads alex.png, AUTO-DETECTS the shirt colour (body front) and the pants colour (leg front),
and paints small shaded swatches in exactly those colours, so the shaping blends into her clothes.
If you change her skin, just run this again:

    python3 tools/generate_body_curves.py

Texture layout (32x16), matched by LayerAlexCurves. Every round shape (a "disc" of 4x5 pixels built from
several boxes with depth 2) samples the same 12x10 shaded tile:
    (0,0)   shirt tile  -> chest
    (16,0)  pants tile  -> hips
The tile is shaded like a sphere (light on the upper left, darker toward the bottom/right) so the discs read round.
"""
import os
from collections import Counter
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
ENT = os.path.join(HERE, "..", "src", "main", "resources", "assets", "alexfriend", "textures", "entity")
SKIN = os.path.join(ENT, "alex.png")
OUT = os.path.join(ENT, "alex_curves.png")


def region_pixels(img, x0, y0, x1, y1):
    px = []
    for y in range(y0, y1):
        for x in range(x0, x1):
            r, g, b, a = img.getpixel((x, y))
            if a > 200:
                px.append((r, g, b))
    return px


def dominant(px):
    """Most common colour (quantised), then the average of everything close to it. Ignores very dark lines."""
    px = [p for p in px if sum(p) > 120]
    if not px:
        return None
    q = Counter((r // 12, g // 12, b // 12) for r, g, b in px)
    key = q.most_common(1)[0][0]
    close = [p for p in px if abs(p[0] // 12 - key[0]) <= 1 and abs(p[1] // 12 - key[1]) <= 1 and abs(p[2] // 12 - key[2]) <= 1]
    n = len(close)
    return tuple(sum(c[i] for c in close) // n for i in range(3))


def detect(img, base_box, overlay_box):
    """Use the clothing overlay layer if it is mostly opaque, otherwise the base layer."""
    ov = region_pixels(img, *overlay_box)
    area = (overlay_box[2] - overlay_box[0]) * (overlay_box[3] - overlay_box[1])
    if len(ov) > area * 0.6:
        return dominant(ov), "overlay"
    return dominant(region_pixels(img, *base_box)), "base"


skin = Image.open(SKIN).convert("RGBA")
# body front: (20,20)-(28,32), overlay (20,36)-(28,48); upper rows only = shirt, not belt
shirt, shirt_src = detect(skin, (20, 20, 28, 27), (20, 36, 28, 43))
# right leg front: (4,20)-(8,32), overlay (4,36)-(8,48); upper rows only = pants, not boots
pants, pants_src = detect(skin, (4, 20, 8, 25), (4, 36, 8, 41))
shirt = shirt or (120, 190, 110)
pants = pants or (110, 75, 50)
print("shirt colour", shirt, "from", shirt_src)
print("pants colour", pants, "from", pants_src)


def shade(c, f):
    return tuple(max(0, min(255, int(v * f))) for v in c) + (255,)


def tile_factor(col, row):
    """Brightness for a tile pixel. Front faces start at (2,2) because the boxes have depth 2."""
    if row < 2:                      # top / bottom faces
        return 1.06 if col < 6 else 0.78
    dx = max(0, min(3, col - 2))
    dy = max(0, min(4, row - 2))
    f = 1.13 - 0.30 * (dy / 4.0) - 0.10 * (dx / 3.0)
    if col < 2:                      # side faces a little darker
        f *= 0.86
    if col > 5:
        f *= 0.86
    if (dx, dy) == (1, 1):           # soft highlight
        f = 1.24
    elif (dx, dy) in ((0, 1), (1, 0), (2, 1), (1, 2)):
        f = max(f, 1.14)
    return f


def paint_tile(img, tx, ty, color):
    for r in range(10):
        for c in range(12):
            img.putpixel((tx + c, ty + r), shade(color, tile_factor(c, r)))


tex = Image.new("RGBA", (32, 16), (0, 0, 0, 0))
paint_tile(tex, 0, 0, shirt)
paint_tile(tex, 16, 0, pants)
tex.save(OUT)
print("wrote", os.path.normpath(OUT))
