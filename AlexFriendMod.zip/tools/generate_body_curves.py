#!/usr/bin/env python3
"""Builds textures/entity/alex_curves.png, the texture of Alex's subtle body shaping.

It reads alex.png, AUTO-DETECTS the shirt colour (body front) and the pants colour (leg front),
and paints small shaded swatches in exactly those colours, so the shaping blends into her clothes.
If you change her skin, just run this again:

    python3 tools/generate_body_curves.py

Texture layout (32x16), matched by LayerAlexCurves:
    (0,0)   chest base   box 3x3x1   (8 x 4 px)
    (8,0)   chest cap    box 2x2x1   (6 x 3 px)
    (16,0)  hip base     box 4x3x1   (10 x 4 px)
    (16,4)  hip cap      box 3x2x1   (8 x 3 px)
"""
import os
from collections import Counter
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
ENT = os.path.join(HERE, "..", "src", "main", "resources", "assets", "alexfriend", "textures", "entity")
SKIN = os.path.join(ENT, "alex.png")
OUT = os.path.join(ENT, "alex_curves.png")


def region_pixels(img, x0, y0, x1, y1):
    px = []
    for y in range(y0, y1):
        for x in range(x0, x1):
            r, g, b, a = img.getpixel((x, y))
            if a > 200:
                px.append((r, g, b))
    return px


def dominant(px):
    """Most common colour (quantised), then the average of everything close to it. Ignores very dark lines."""
    px = [p for p in px if sum(p) > 120]
    if not px:
        return None
    q = Counter((r // 12, g // 12, b // 12) for r, g, b in px)
    key = q.most_common(1)[0][0]
    close = [p for p in px if abs(p[0] // 12 - key[0]) <= 1 and abs(p[1] // 12 - key[1]) <= 1 and abs(p[2] // 12 - key[2]) <= 1]
    n = len(close)
    return tuple(sum(c[i] for c in close) // n for i in range(3))


def detect(img, base_box, overlay_box):
    """Use the clothing overlay layer if it is mostly opaque, otherwise the base layer."""
    ov = region_pixels(img, *overlay_box)
    area = (overlay_box[2] - overlay_box[0]) * (overlay_box[3] - overlay_box[1])
    if len(ov) > area * 0.6:
        return dominant(ov), "overlay"
    return dominant(region_pixels(img, *base_box)), "base"


skin = Image.open(SKIN).convert("RGBA")
# body front: (20,20)-(28,32), overlay (20,36)-(28,48); upper rows only = shirt, not belt
shirt, shirt_src = detect(skin, (20, 20, 28, 27), (20, 36, 28, 43))
# right leg front: (4,20)-(8,32), overlay (4,36)-(8,48); upper rows only = pants, not boots
pants, pants_src = detect(skin, (4, 20, 8, 25), (4, 36, 8, 41))
shirt = shirt or (120, 190, 110)
pants = pants or (110, 75, 50)
print("shirt colour", shirt, "from", shirt_src)
print("pants colour", pants, "from", pants_src)


def shade(c, f):
    return tuple(max(0, min(255, int(v * f))) for v in c) + (255,)


def paint_box(img, ox, oy, w, h, d, color):
    """Paint the six faces of a Minecraft box UV net with soft shading (light on top, darker underneath)."""
    # top / bottom
    for x in range(w):
        for y in range(d):
            img.putpixel((ox + d + x, oy + y), shade(color, 1.10))
            img.putpixel((ox + d + w + x, oy + y), shade(color, 0.72))
    # sides + front + back, vertical gradient
    for y in range(h):
        t = y / max(1, h - 1)
        f = 1.06 - 0.22 * t
        for x in range(d):
            img.putpixel((ox + x, oy + d + y), shade(color, f * 0.86))            # right side
            img.putpixel((ox + d + w + x, oy + d + y), shade(color, f * 0.86))    # left side
        for x in range(w):
            fr = f
            # a touch of highlight on the upper-left of the front, soft shadow on the lower-right
            if x == 0 and y == 0:
                fr = 1.16
            if x == w - 1 and y == h - 1:
                fr = 0.82
            img.putpixel((ox + d + x, oy + d + y), shade(color, fr))              # front
            img.putpixel((ox + 2 * d + w + x, oy + d + y), shade(color, f * 0.9))  # back


tex = Image.new("RGBA", (32, 16), (0, 0, 0, 0))
paint_box(tex, 0, 0, 3, 3, 1, shirt)
paint_box(tex, 8, 0, 2, 2, 1, shirt)
paint_box(tex, 16, 0, 4, 3, 1, pants)
paint_box(tex, 16, 4, 3, 2, 1, pants)
tex.save(OUT)
print("wrote", os.path.normpath(OUT))
