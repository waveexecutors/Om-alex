#!/usr/bin/env python3
"""Generates Alex's face layers (16x16 each) into textures/entity/face/.

Layers (drawn on top of the faceless skin by LayerAlexFace):
  eyes_<name>.png   big cute eyes with highlights
  mouth_<name>.png  small mouths
  blush_light.png / blush_strong.png

Run:  python3 tools/generate_faces.py
Needs Pillow. Edit the palette / patterns below to restyle her.
"""
import os
from PIL import Image

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..",
                   "src", "main", "resources", "assets", "alexfriend", "textures", "entity", "face")
os.makedirs(OUT, exist_ok=True)
for f in os.listdir(OUT):
    if f.endswith(".png"):
        os.remove(os.path.join(OUT, f))

# ---------------------------------------------------------------- palette
O = (104, 60, 72, 255)       # lash line (soft brown, not black)
O2 = (150, 98, 104, 255)     # softer lash corner
D = (30, 112, 92, 255)       # iris top (deep teal-green)
M = (66, 176, 128, 255)      # iris middle
L = (170, 240, 190, 255)     # iris bottom glow
P = (26, 24, 48, 255)        # pupil
W = (255, 255, 255, 255)     # sparkle
H = (255, 76, 116, 255)      # heart eyes
HW = (255, 196, 210, 255)    # heart shine
LIP = (182, 66, 88, 255)     # mouth line
IN = (126, 36, 58, 255)      # mouth inside
TG = (255, 132, 148, 255)    # tongue
PK = (240, 100, 128, 255)    # pucker lips
PKH = (255, 176, 190, 255)   # lip shine
T = (0, 0, 0, 0)

LEFT_X = 1      # left eye block x origin (5 wide)
RIGHT_X = 10    # right eye block x origin
EYE_Y = 8       # eye block y origin (6 tall)
ROWS = 6


def new():
    return Image.new("RGBA", (16, 16), T)


def put(img, x, y, c):
    if 0 <= x < 16 and 0 <= y < 16:
        img.putpixel((x, y), c)


KEY = {"O": O, "o": O2, "D": D, "M": M, "L": L, "P": P, "W": W, "H": H, "h": HW, ".": None}


def draw_block(img, ox, rows):
    assert len(rows) == ROWS and all(len(r) == 5 for r in rows), rows
    for ry, row in enumerate(rows):
        for rx, ch in enumerate(row):
            c = KEY[ch]
            if c:
                put(img, ox + rx, EYE_Y + ry, c)


def both(rows_left, rows_right=None):
    """Draw both eyes. If rows_right is None the left pattern is mirrored for the right eye."""
    img = new()
    if rows_right is None:
        rows_right = [r[::-1] for r in rows_left]
    draw_block(img, LEFT_X, rows_left)
    draw_block(img, RIGHT_X, rows_right)
    return img


def open_eye(look):
    """look: -1 pupils toward texture-left, 0 centre, +1 toward texture-right.
    Left-eye pattern (outer corner = column 0); the right eye is the mirror image."""
    grid = [list(".OOOO"),
            list("ODDDD"),
            list("DDDDD"),
            list("DDDDD"),
            list("MMMMM"),
            list(".LLL.")]
    pc = {-1: 0, 0: 1, 1: 3}[look]          # left column of the 2-wide pupil
    for ry in (2, 3):
        grid[ry][pc] = "P"
        grid[ry][pc + 1] = "P"
    grid[1][pc] = "D"
    grid[2][pc] = "W"                        # big sparkle on the pupil's upper-left
    sx = pc + 2 if pc + 2 <= 4 else 4
    grid[4][sx] = "W"                        # tiny sparkle low on the other side
    return ["".join(r) for r in grid]


def half_eye(look=0):
    pc = {-1: 0, 0: 1, 1: 3}[look]
    grid = [list("....."),
            list("....."),
            list(".OOOO"),
            list("DDDDD"),
            list("MMMMM"),
            list(".LLL.")]
    grid[3][pc] = "P"
    grid[3][pc + 1] = "P"
    return ["".join(r) for r in grid]


CLOSED = [".....", ".....", ".....", ".....", ".OOO.", "....."]
CLOSED_CURVE = [".....", ".....", ".....", "O...O", ".OOO.", "....."]   # sleepy / kissing "u u"
HAPPY = [".....", ".....", ".OOO.", "O...O", ".....", "....."]            # ^ ^
SAD = ["..OOO", ".ODDD", "DWPPD", "DPPPD", "MMMMM", ".LLL."]
SURPRISED = [".OOO.", "OWWWO", "OWPPO", "OWPPO", "OWWWO", ".OOO."]
SHY = [".....", ".OOOO", "ODWPD", "DDPPD", "MMMMM", ".LLL."]
LOVE_A = ["HH.HH", "HhHHH", "HHHHH", "HHHHH", ".HHH.", "..H.."]
LOVE_B = [".....", ".H.H.", "HhHHH", ".HHH.", "..H..", "....."]

eyes = {
    "open_c": both(open_eye(0)),
    "open_l": both(open_eye(-1)),
    "open_r": both(open_eye(1)),
    "half": both(half_eye(0)),
    "closed": both(CLOSED),
    "kiss": both(CLOSED_CURVE),
    "happy": both(HAPPY),
    "sad": both(SAD),
    "surprised": both(SURPRISED),
    "shy": both(SHY),
    "love_a": both(LOVE_A),
    "love_b": both(LOVE_B),
}
# little lash flick on the outer top corner of the open eyes
for name in ("open_c", "open_l", "open_r", "sad"):
    put(eyes[name], LEFT_X - 1, EYE_Y, O)
    put(eyes[name], RIGHT_X + 5, EYE_Y, O)
put(eyes["shy"], LEFT_X - 1, EYE_Y + 1, O)
put(eyes["shy"], RIGHT_X + 5, EYE_Y + 1, O)
put(eyes["half"], LEFT_X - 1, EYE_Y + 2, O)
put(eyes["half"], RIGHT_X + 5, EYE_Y + 2, O)
for name in ("kiss", "closed"):
    put(eyes[name], LEFT_X - 1, EYE_Y + 3, O)
    put(eyes[name], RIGHT_X + 5, EYE_Y + 3, O)

for k, im in eyes.items():
    im.save(os.path.join(OUT, "eyes_%s.png" % k))

# ---------------------------------------------------------------- mouths (x 6..9, rows 14-15)


def mouth(pixels):
    img = new()
    for (x, y, c) in pixels:
        put(img, x, y, c)
    return img


mouths = {
    "neutral": mouth([(7, 14, LIP), (8, 14, LIP)]),
    "smile": mouth([(6, 14, LIP), (9, 14, LIP), (7, 15, LIP), (8, 15, LIP)]),
    "grin": mouth([(6, 14, LIP), (7, 14, LIP), (8, 14, LIP), (9, 14, LIP),
                   (7, 15, IN), (8, 15, TG)]),
    "talk": mouth([(7, 14, IN), (8, 14, IN), (7, 15, IN), (8, 15, TG)]),
    "o": mouth([(7, 14, LIP), (8, 14, LIP), (7, 15, IN), (8, 15, IN)]),
    "frown": mouth([(7, 14, LIP), (8, 14, LIP), (6, 15, LIP), (9, 15, LIP)]),
    "pucker": mouth([(7, 14, PK), (8, 14, PKH), (7, 15, PK), (8, 15, PK)]),
}
for k, im in mouths.items():
    im.save(os.path.join(OUT, "mouth_%s.png" % k))

# ---------------------------------------------------------------- blush (just under the eyes)
light = new()
strong = new()
for ox in (1, 11):
    for dx in range(3):
        put(light, ox + dx, 14, (255, 122, 142, 100))
        put(strong, ox + dx, 14, (255, 105, 130, 185))
        put(strong, ox + dx, 15, (255, 105, 130, 130))
light.save(os.path.join(OUT, "blush_light.png"))
strong.save(os.path.join(OUT, "blush_strong.png"))

print("wrote", len(os.listdir(OUT)), "face layers to", os.path.normpath(OUT))
