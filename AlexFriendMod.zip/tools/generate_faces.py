#!/usr/bin/env python3
"""Generates Alex's face layers (16x16 each) into textures/entity/face/.

Layers (drawn on top of the faceless skin by LayerAlexFace):
  eyes_<name>.png   big cute eyes with highlights
  mouth_<name>.png  small mouths
  blush_light.png / blush_strong.png

Run:  python3 tools/generate_faces.py
Needs Pillow. Edit the palette / patterns below to restyle her.
"""
import os
from PIL import Image

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..",
                   "src", "main", "resources", "assets", "alexfriend", "textures", "entity", "face")
os.makedirs(OUT, exist_ok=True)
for f in os.listdir(OUT):
    if f.endswith(".png"):
        os.remove(os.path.join(OUT, f))

# ---------------------------------------------------------------- palette
O = (96, 54, 68, 255)        # lash line / outline
D = (28, 104, 84, 255)       # iris top (dark teal-green)
M = (60, 170, 120, 255)      # iris middle
L = (150, 232, 176, 255)     # iris bottom glow
P = (24, 22, 44, 255)        # pupil
W = (255, 255, 255, 255)     # sparkle
H = (255, 72, 112, 255)      # heart eyes
HW = (255, 190, 205, 255)    # heart shine
LIP = (176, 62, 84, 255)     # mouth line
IN = (122, 34, 56, 255)      # mouth inside
TG = (255, 128, 144, 255)    # tongue
PK = (238, 96, 124, 255)     # pucker lips
PKH = (255, 170, 186, 255)   # lip shine
T = (0, 0, 0, 0)

LEFT_X = 1      # left eye block x origin (5 wide)
RIGHT_X = 10    # right eye block x origin
EYE_Y = 8       # eye block y origin (5 tall)


def new():
    return Image.new("RGBA", (16, 16), T)


def put(img, x, y, c):
    if 0 <= x < 16 and 0 <= y < 16:
        img.putpixel((x, y), c)


def draw_block(img, ox, rows):
    """rows: list of 5 strings of 5 chars -> pixels. '.' is transparent."""
    key = {"O": O, "D": D, "M": M, "L": L, "P": P, "W": W, "H": H, "h": HW, ".": None}
    for ry, row in enumerate(rows):
        for rx, ch in enumerate(row):
            c = key[ch]
            if c:
                put(img, ox + rx, EYE_Y + ry, c)


def both(rows_left, rows_right=None):
    """Draw both eyes. If rows_right is None the left pattern is mirrored for the right eye."""
    img = new()
    if rows_right is None:
        rows_right = [r[::-1] for r in rows_left]
    draw_block(img, LEFT_X, rows_left)
    draw_block(img, RIGHT_X, rows_right)
    return img


def open_eye(look):
    """look: -1 pupils toward texture-left, 0 centre, +1 toward texture-right."""
    grid = [list("OOOOO"),
            list("DDDDD"),
            list("DDDDD"),
            list("MMMMM"),
            list(".LLL.")]
    pc = {-1: 0, 0: 1, 1: 3}[look]          # left column of the 2-wide pupil
    for ry in (1, 2, 3):
        grid[ry][pc] = "P"
        grid[ry][pc + 1] = "P"
    grid[1][pc] = "W"                        # big sparkle (upper-left of pupil)
    grid[2][pc] = "W"
    sx = pc + 2 if pc + 2 <= 4 else 4        # tiny sparkle (lower-right)
    grid[3][sx] = "W"
    return ["".join(r) for r in grid]


def half_eye(look=0):
    pc = {-1: 0, 0: 1, 1: 3}[look]
    grid = [list("....."),
            list("....."),
            list("OOOOO"),
            list("MPPMM"),
            list(".LLL.")]
    grid[3] = list("MMMMM")
    grid[3][pc] = "P"
    grid[3][pc + 1] = "P"
    return ["".join(r) for r in grid]


CLOSED = [".....", ".....", ".....", ".OOO.", "....."]
CLOSED_CURVE = [".....", ".....", "O...O", ".OOO.", "....."]         # sleepy / kissing "u u"
HAPPY = [".....", ".OOO.", "O...O", ".....", "....."]                 # ^ ^
SAD_L = [".OOOO", "ODDDD", "DWPPD", "DWPPM", ".LLL."]
SAD_R = ["OOOO.", "DDDDO", "DPPWD", "MPPWD", ".LLL."]
SURPRISED = [".OOO.", "OWWWO", "OWPPO", "OWPPO", ".OOO."]
SHY = [".....", "OOOOO", "DWPPD", "MMPPM", ".LLL."]
LOVE_A = ["HH.HH", "HhHHH", "HHHHH", ".HHH.", "..H.."]
LOVE_B = [".....", ".H.H.", ".HHH.", "..H..", "....."]

eyes = {
    "open_c": both(open_eye(0)),
    "open_l": both(open_eye(-1)),
    "open_r": both(open_eye(1)),
    "half": both(half_eye(0)),
    "closed": both(CLOSED),
    "kiss": both(CLOSED_CURVE),
    "happy": both(HAPPY),
    "sad": both(SAD_L, SAD_R),
    "surprised": both(SURPRISED),
    "shy": both(SHY),
    "love_a": both(LOVE_A),
    "love_b": both(LOVE_B),
}
# small flick on the outer lash corner of open eyes for extra cuteness
for name in ("open_c", "open_l", "open_r", "sad"):
    put(eyes[name], LEFT_X - 1, EYE_Y, O)
    put(eyes[name], RIGHT_X + 5, EYE_Y, O)
for name in ("shy", "half"):
    put(eyes[name], LEFT_X - 1, EYE_Y + (1 if name == "shy" else 2), O)
    put(eyes[name], RIGHT_X + 5, EYE_Y + (1 if name == "shy" else 2), O)
for name in ("kiss", "closed"):
    put(eyes[name], LEFT_X - 1, EYE_Y + 2, O)
    put(eyes[name], RIGHT_X + 5, EYE_Y + 2, O)

for k, im in eyes.items():
    im.save(os.path.join(OUT, "eyes_%s.png" % k))

# ---------------------------------------------------------------- mouths (centre x = 6..9, rows 13-14)


def mouth(pixels):
    img = new()
    for (x, y, c) in pixels:
        put(img, x, y, c)
    return img


mouths = {
    "neutral": mouth([(7, 13, LIP), (8, 13, LIP)]),
    "smile": mouth([(6, 13, LIP), (9, 13, LIP), (7, 14, LIP), (8, 14, LIP)]),
    "grin": mouth([(6, 13, LIP), (7, 13, LIP), (8, 13, LIP), (9, 13, LIP),
                   (7, 14, IN), (8, 14, TG)]),
    "talk": mouth([(7, 13, IN), (8, 13, IN), (7, 14, IN), (8, 14, TG)]),
    "o": mouth([(7, 13, LIP), (8, 13, LIP), (7, 14, IN), (8, 14, IN)]),
    "frown": mouth([(7, 13, LIP), (8, 13, LIP), (6, 14, LIP), (9, 14, LIP)]),
    "pucker": mouth([(7, 13, PK), (8, 13, PKH), (7, 14, PK), (8, 14, PK)]),
}
for k, im in mouths.items():
    im.save(os.path.join(OUT, "mouth_%s.png" % k))

# ---------------------------------------------------------------- blush
light = new()
strong = new()
for ox in (1, 11):
    for dx in range(3):
        put(light, ox + dx, 13, (255, 120, 140, 95))
        put(strong, ox + dx, 13, (255, 105, 130, 175))
        put(strong, ox + dx, 14, (255, 105, 130, 140))
light.save(os.path.join(OUT, "blush_light.png"))
strong.save(os.path.join(OUT, "blush_strong.png"))

print("wrote", len(os.listdir(OUT)), "face layers to", os.path.normpath(OUT))
